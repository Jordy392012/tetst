# AURORA architecture

## Audio scheduling

The render path is designed around the FM-1's short DMA deadline. The engine processes at most 256 frames per inner render chunk. Sequencer events can split that chunk further so note gates and 16th-note boundaries are not rounded to the nearest full audio block.

1. Core 0 applies pending control commands and advances the sequencer.
2. If the platform exposes a CPU1 worker, core 0 submits voices 8–15 to it.
3. Core 0 renders voices 0–7 while CPU1 renders voices 8–15 into a separate stereo accumulator.
4. Core 0 waits for the worker with a bounded timeout.
5. Successful worker output is added to the core-0 bus. Master delay, reverb, chorus, drive, filtering and limiting are applied on core 0.
6. If CPU1 misses the deadline, core 0 asks the platform to retire it. The board adapter must not report success until the worker is parked and can no longer touch shared RAM.

The host build runs CPU1 jobs on a persistent pthread/Win32 thread. This validates the concurrency contract but does not establish timing or stability on the physical FM-1.

## Memory

The project data model stores eight tracks × 16 patterns × 64 steps. Presets are generated into a compact in-memory table at initialization; there are no large multisample banks. Delay, chorus and reverb buffers are fixed-size arrays. The caller owns the complete engine instance and must check `aurora_instance_size()` against the RAM budget used by its board build.

The FM-1 has a small on-chip SRAM budget and no external RAM, so a target port should place the hot DSP path in SRAM, keep UI and storage work out of the audio interrupt, and measure peak block time on hardware. See the FM-1 developers' wiki for the measured audio scheduling and SRAM notes.

## Synth design

- **Analog:** two detuned oscillators plus a sub oscillator, with four oscillator wave shapes.
- **FM:** four phase operators arranged as a compact modulation stack.
- **Wavetable/additive:** harmonic stacks with a slowly moving spectral balance.
- **Pluck:** damped harmonic resonator with a short noise transient.
- **Organ:** additive drawbar-like partials.
- **Drums:** tuned kick/tom voices and noise-based snare/hat voices.

These are lightweight procedural engines. They do not depend on copyrighted sample libraries or external sample files.
