# AURORA FM1 preset bank

**128 built-in presets** across six synthesis engines. Presets are generated procedurally; no external sample library is required.

## Analog subtractive (24)

000. Velvet Keys
001. Warm Saw
002. Glass Poly
003. Soft Brass
004. Tape Strings
005. Juno Mist
006. Rubber Bass
007. Round Sub
008. Neon Lead
009. Hollow Pluck
010. Wide PWM
011. Slow Sunrise
012. Electric Silk
013. Chime Pad
014. Muted Pulse
015. Blue Machine
016. Analog Choir
017. Deep Motion
018. Mono Glide
019. Amber Organ
020. Soft Sync
021. Night Brass
022. Low Orbit
023. Dream Sequence

## FM (24)

024. FM Bell Glass
025. DX Marimba
026. Crystal EP
027. Tine Piano
028. FM Celesta
029. Metal Bloom
030. Digital Harp
031. Shimmer Bell
032. FM Bass 01
033. FM Bass 02
034. Rubber FM
035. Operator Stack
036. Glass Mallet
037. FM Brass
038. Vox Pixels
039. Ice Keys
040. FM Guitar
041. Tiny Chimes
042. Bright EP
043. Soft EP
044. FM Pluck
045. Hollow Metal
046. Retro Data
047. Starfield

## Wavetable / additive (20)

048. Wavetable Air
049. Morphing Pad
050. Spectral Rain
051. Digital Dawn
052. Vowel Sweep
053. Neon Choir
054. Phase Garden
055. Liquid Glass
056. Granite Lead
057. Wavetable Bass
058. Slow Motion
059. Cloud Atlas
060. Frosted Keys
061. Prism Arp
062. Synthetic Reed
063. Radiant Wash
064. Harmonic Dust
065. Future Brass
066. Night Bloom
067. Vector Pulse

## Pluck / resonator (20)

068. Nylon Room
069. Wooden Mallet
070. Muted Guitar
071. Kalimba Air
072. Marimba Soft
073. Picked Glass
074. Pluck Sequence
075. Cedar Strings
076. Thumb Piano
077. Tiny Harp
078. Damped Steel
079. Bamboo Pluck
080. Bellwood
081. Soft Banjo
082. Hollow Kalimba
083. String Pebbles
084. Rain Drops
085. Warm Mandolin
086. Pluck Bass
087. Resonant Wood

## Tonewheel organ (16)

088. Jazz Drawbars
089. Theatre Organ
090. Soft Gospel
091. Rotary Clean
092. Smoke Organ
093. Combo 60s
094. Church Glass
095. Muted B3
096. Blue Note
097. Organ Bass
098. Slow Leslie
099. Reed Organ
100. Soul Machine
101. Vintage Combo
102. Air Cathedral
103. Late Night Organ

## Synthesized drums (24)

104. Deep Kick
105. Punch Kick
106. Soft Kick
107. 808 Sub
108. Acoustic Snare
109. Tight Snare
110. Brush Snare
111. Clap Stack
112. Closed Hat
113. Open Hat
114. Shaker
115. Metal Ride
116. Low Tom
117. High Tom
118. Analog Perc
119. FM Perc
120. Wood Block
121. Rim Click
122. Noise Sweep
123. Laser Drum
124. Break Kit
125. Jazz Kit
126. Dusty Kit
127. Machine Kit
