# AURORA FM-1 port status

**Status:** First application-level adapter implemented; no validated `.fwsc` has been built.

The adapter is in [`../fm1/`](../fm1/README.md) and targets [`charlesvestal/fm1-base`](https://github.com/charlesvestal/fm1-base), with its `felucca-bsp` submodule. That is the intended route because the base supplies an FM-1 application contract, physical panel/audio/MIDI/storage drivers, a host platform simulator, a browser emulator, and the device package builder. AURORA's own engine source is copied into `fm1/engine/`; the target copy uses fm1-base's `fastmath.h` routines so it does not require a floating-point `libm` at firmware link time.

## Implemented in this source tree

- FM-1 app contract: `app_init`, `app_render`, `app_panic`, `app_ui_init`, `app_frame`, `app_input_only` and `app_say`.
- 256-frame stereo audio callback adapter; float output is clipped and converted to signed 24-bit samples.
- Keybed note input, velocity sensing, USB MIDI output, USB/TRS MIDI input, and TRS-to-USB forwarding.
- First-pass UI and controls for track, pattern, preset, tempo, effects, transport, step recording, erase, swing, octave and song-event editing.
- Two alternating flash project slots. Project writes are page-sized, CRC-protected and committed header-last; read-back is checked and the previous valid slot is retained. Load tries the newest candidate first and falls back to the older valid candidate if either the outer flash record or the inner AURORA project fails validation.
- A local fake-platform test harness. It tests callback sample range, audible output, MIDI direction, controls, recording, save/reload, A/B corruption recovery, song-event add/remove, command queue status and intentional CPU0-only mode.
- A native engine test covers the portable engine and 256-frame, 16-voice CPU0 output. The local regression binaries each passed 100 consecutive runs during this port pass.

## Not verified yet

1. **Upstream platform host simulation:** run `fm1-base/tools/build.py fm1 --host` and its script tests. This full simulator build has not run in the current environment.
2. **Browser app simulator:** run `fm1-base/tools/build.py fm1 --web` with Emscripten. This full WebAssembly build has not run in the current environment. It runs the app against fm1-base's platform model, rather than emulating the AC791N CPU.
3. **Full-chip emulator:** after a genuine package exists, load that exact `.fwsc` in the [FM-1 Emulator](https://joakimeriksson.github.io/fm1-emu/) using its “Open .fwsc…” input and press Start. It emulates the AC791N and boots firmware packages unchanged. This has not been run because this pass did not produce `aurora.fwsc`; browser emulation speed/load is not hardware timing proof.
4. **Device firmware build:** the JieLi PI32v2 toolchain and matching AC79 SDK assets were not available here. Consequently there is no `aurora.fwsc`, linked target map, loader, or validated package to install.
5. **Physical hardware:** no FM-1 board was available. Cold boot, display and controls, USB/TRS MIDI, audio DMA format, 16-voice/effects timing, flash writes, power-loss recovery and repeated save/load remain untested.
6. **CPU1:** deliberately disabled in `fm1/fm1.toml`. The portable engine's host worker is not device CPU1. Enabling the second core needs a platform implementation of submit/wait/safe-retire, target-side deadline checks and physical verification.
7. **Feature completion:** the current UI is a playable first pass, not a finished synth workstation. The song editor appends/removes one-repeat events; it does not yet offer a full song-event editor or every per-step parameter page. Bluetooth MIDI is disabled in this configuration.

## Requirements to finish the real firmware build

Clone fm1-base with its submodule:

```sh
git clone --recursive https://github.com/charlesvestal/fm1-base.git
```

Install the exact PI32v2 toolchain and AC79 SDK assets required by the current fm1-base build. The build expects its pinned assets, not arbitrary files copied from the FM1 Open V14 zip. The toolchain is JieLi clang 4.0.1 for pi32v2; on Linux x86-64 point `JIELI_TOOLCHAIN` at the directory containing `pi32v2/` and `common/`. The device build reads `AC79_SDK` (or `--sdk`) and expects the `AC79NN_SDK_V1.2.1_2023-12-13` files. The documented pinned SHA-256 values are:

| File | SHA-256 |
|---|---|
| `jieli-linux-toolchains-20250324.1.tar.xz` | `f686586bcfb45e0f0bb27fd2b39c7a7f313cb4f0e88a66a14da621ffa8225958` |
| `cpu/wl82/tools/uboot.boot` | `4e3b4c220dc96641cb5a723f41e68ce41d5261ae9434bb33fbd7f2c59976ded4` |
| `cpu/wl82/tools/cfg_tool.bin` | `276579954f076886a6a7694f65dc71c034a63a2c204b76749065c0ac7b010d1b` |
| `cpu/wl82/tools/cfg/eq_cfg_hw.bin` | `41167491bffed4651750719c973d2758adeb9021a5670d02d6a53c85ed80ea7d` |

The host build needs only a native C compiler; the `--web` app simulator needs Emscripten; the firmware build needs the target toolchain plus those SDK files. The wiki's Getting Started guide describes the supported Linux/Docker setup and recovery prerequisites. Then, from a workspace containing `AURORA-FM1/` and `fm1-base/`, run:

```sh
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --host
AURORA-FM1/fm1/build/host/aurora_host AURORA-FM1/fm1/tests/basic.txt AURORA-FM1/fm1/build/host
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --web
python3 fm1-base/tools/build.py AURORA-FM1/fm1
```

The device command should produce `AURORA-FM1/fm1/build/aurora.fwsc` only after fm1-base's target compilation, linker layout, RAM-call, stack/memory and package checks all pass. A successful compile is still not hardware validation; record worst-case render block duration with all voices and effects active before treating the app as ready for normal use.

Before the first install, make and verify a full flash backup and understand the device's stock recovery procedure. Follow fm1-base's own Getting Started guide for device-specific prerequisites (including whether a stock firmware restore is needed). Do not erase/overwrite a device's boot or calibration areas manually.

## The earlier experimental package

An earlier `.fwsc` generated during the previous attempt only contained an AURORA-branded FM1 Open V14 baseline. It did not contain the AURORA synth engine, and the emulator showed reset behavior. **Do not flash it.** The adapter source in `fm1/` is the genuine integration work; it has not yet been compiled into a device `.fwsc` here.

### Command queue publication barrier

The command queue uses a compiler publication barrier between writing a slot and
advancing its volatile index. On the single-core PI32v2 target, this is the same
empty inline-assembly memory clobber used by fm1-base's `RING_PUBLISH()`; it avoids
`__sync_synchronize`, which PI32v2 otherwise leaves as an unresolved helper at link
time. Native GNU host builds retain the full `__sync_synchronize()` fence for
threaded tests. This is not an SMP hardware fence: CPU2 remains disabled in this
initial port, and enabling it requires a separately designed and measured cross-core
synchronization path.
