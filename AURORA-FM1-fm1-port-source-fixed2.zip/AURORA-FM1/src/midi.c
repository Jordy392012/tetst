#include "aurora_midi.h"
#include <string.h>

void aurora_midi_init(AuroraMidiParser *p) {
    if (p) memset(p, 0, sizeof(*p));
}

static void midi_realtime(Aurora *a, AuroraMidiParser *p, uint8_t b, uint32_t now_ms) {
    if (b == 0xF8u) {
        p->clock_count++;
        if (p->clock_count >= 24u) {
            if (p->have_quarter) {
                uint32_t elapsed = now_ms - p->last_quarter_ms;
                if (elapsed >= 250u && elapsed <= 2000u) {
                    uint16_t bpm = (uint16_t)(60000u / elapsed);
                    if (bpm >= 30u && bpm <= 240u) aurora_set_tempo(a, bpm);
                }
            }
            p->last_quarter_ms = now_ms;
            p->have_quarter = 1u;
            p->clock_count = 0u;
        }
        p->last_clock_ms = now_ms;
    } else if (b == 0xFAu) {
        aurora_play(a);
    } else if (b == 0xFBu) {
        aurora_play(a);
    } else if (b == 0xFCu) {
        aurora_stop(a);
    }
}

static void dispatch_channel(Aurora *a, uint8_t status, uint8_t d1, uint8_t d2) {
    uint8_t kind = status & 0xF0u;
    uint8_t channel = status & 0x0Fu;
    uint8_t track = (uint8_t)(channel % AURORA_TRACKS);
    if (kind == 0x90u) {
        if (d2 == 0u) aurora_note_off(a, track, d1);
        else aurora_note_on(a, track, d1, d2);
    } else if (kind == 0x80u) {
        aurora_note_off(a, track, d1);
    } else if (kind == 0xB0u) {
        if (d1 == 7u) aurora_set_track_level(a, track, (float)d2 / 127.0f);
        else if (d1 == 10u) aurora_set_track_pan(a, track, ((float)d2 / 63.5f) - 1.0f);
        else if (d1 == 120u || d1 == 123u) aurora_all_notes_off(a);
    } else if (kind == 0xC0u) {
        aurora_set_track_preset(a, track, d1);
    }
}

void aurora_midi_feed(Aurora *a, AuroraMidiParser *p, uint8_t byte, uint32_t now_ms) {
    uint8_t kind;
    if (!a || !p) return;
    if (byte >= 0xF8u) { midi_realtime(a, p, byte, now_ms); return; }
    if (byte & 0x80u) {
        if (byte >= 0xF0u) { p->running_status = 0u; p->data_count = 0u; p->data_needed = 0u; return; }
        p->running_status = byte;
        kind = byte & 0xF0u;
        p->data_count = 0u;
        p->data_needed = (kind == 0xC0u || kind == 0xD0u) ? 1u : 2u;
        return;
    }
    if (!p->running_status || !p->data_needed) return;
    p->data[p->data_count++] = byte & 0x7Fu;
    if (p->data_count >= p->data_needed) {
        dispatch_channel(a, p->running_status, p->data[0], p->data_needed > 1u ? p->data[1] : 0u);
        p->data_count = 0u;
    }
}
