#include "aurora_internal.h"

/* PI32v2 is the single-core FM-1 target. Use the platform's compiler-only
   publication barrier there; its unity build uses the same empty-asm idiom.
   Native host builds keep a full fence for threaded tests. CPU2 stays off. */
#if defined(__PI32V2__)
#define AURORA_QUEUE_BARRIER() __asm__ volatile("" ::: "memory")
#elif defined(__GNUC__)
#define AURORA_QUEUE_BARRIER() __sync_synchronize()
#else
#define AURORA_QUEUE_BARRIER() ((void)0)
#endif
#include <stdlib.h>

static int queue_push(Aurora *a, const AuroraCommand *cmd) {
    AuroraCommandQueue *q = &a->commands;
    uint16_t next = (uint16_t)((q->head + 1u) % AURORA_CMD_CAP);
    if (next == q->tail) { q->dropped++; return 0; }
    q->item[q->head] = *cmd;
    AURORA_QUEUE_BARRIER();
    q->head = next;
    return 1;
}

static int queue_pop(Aurora *a, AuroraCommand *cmd) {
    AuroraCommandQueue *q = &a->commands;
    if (q->tail == q->head) return 0;
    *cmd = q->item[q->tail];
    AURORA_QUEUE_BARRIER();
    q->tail = (uint16_t)((q->tail + 1u) % AURORA_CMD_CAP);
    return 1;
}

uint32_t aurora_random(Aurora *a) {
    uint32_t x = a->rng;
    if (!x) x = 0xA341316Cu;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    a->rng = x;
    return x;
}

static void set_step_period(Aurora *a) {
    uint32_t base = ((AURORA_SAMPLE_RATE * 60u) / ((uint32_t)a->bpm * 4u));
    uint32_t swing = a->swing;
    if ((a->step_index & 1u) == 0u) base = (base * (100u + swing)) / 100u;
    else base = (base * (100u - swing)) / 100u;
    a->step_base_frames = base ? base : 1u;
}

static AuroraPattern *current_pattern(Aurora *a, uint8_t track) {
    uint8_t p = a->tracks[track].pattern;
    if (a->song_mode && a->tracks[track].song_length) {
        uint8_t pos = a->tracks[track].song_position;
        if (pos >= a->tracks[track].song_length) pos = 0u;
        p = a->tracks[track].song[pos].pattern;
    }
    return &a->patterns[track][p & 15u];
}

void aurora_start_note(Aurora *a, uint8_t track, uint8_t note, uint8_t velocity) {
    uint32_t i;
    int chosen = -1;
    uint32_t oldest = 0xffffffffu;
    AuroraVoice *v;
    if (track >= AURORA_TRACKS || note > 127u || velocity == 0u) return;
    for (i = 0; i < AURORA_VOICES; ++i) {
        if (!a->voices[i].active) { chosen = (int)i; break; }
        if (a->voices[i].stage == ENV_RELEASE && a->voices[i].age < oldest) {
            oldest = a->voices[i].age; chosen = (int)i;
        }
    }
    if (chosen < 0) {
        oldest = 0xffffffffu;
        for (i = 0; i < AURORA_VOICES; ++i) {
            if (a->voices[i].age < oldest) { oldest = a->voices[i].age; chosen = (int)i; }
        }
    }
    if (chosen < 0) return;
    v = &a->voices[(uint32_t)chosen];
    memset(v, 0, sizeof(*v));
    v->active = 1u;
    v->stage = ENV_ATTACK;
    v->note = note;
    v->velocity = velocity;
    v->track = track;
    v->preset = (uint8_t)(a->tracks[track].preset % AURORA_PRESET_COUNT);
    v->base_freq = 440.0f * powf(2.0f, ((float)note - 69.0f) / 12.0f);
    v->age = ++a->voice_age;
    v->noise_rng = (uint32_t)(0x9E3779B9u ^ (v->age * 0x85EBCA6Bu) ^ ((uint32_t)note << 16));
    if (!v->noise_rng) v->noise_rng = 1u;
}

void aurora_release_note(Aurora *a, uint8_t track, uint8_t note) {
    uint32_t i;
    for (i = 0; i < AURORA_VOICES; ++i) {
        AuroraVoice *v = &a->voices[i];
        if (v->active && v->track == track && v->note == note && v->stage != ENV_RELEASE) {
            const AuroraPreset *p = &a->presets[v->preset];
            float release = fmaxf(p->release, 0.015f);
            v->release_step = v->env / (release * (float)AURORA_SAMPLE_RATE);
            v->stage = ENV_RELEASE;
        }
    }
}

static void all_notes_off_now(Aurora *a) {
    uint32_t i;
    for (i = 0; i < AURORA_VOICES; ++i) {
        AuroraVoice *v = &a->voices[i];
        if (v->active && v->stage != ENV_RELEASE) {
            const AuroraPreset *p = &a->presets[v->preset];
            v->release_step = v->env / (fmaxf(p->release, 0.015f) * (float)AURORA_SAMPLE_RATE);
            v->stage = ENV_RELEASE;
        }
    }
    for (i = 0; i < AURORA_TRACKS; ++i) {
        a->active_note[i] = 255u;
        a->gate_remaining[i] = 0u;
    }
}

void aurora_apply_commands(Aurora *a) {
    AuroraCommand c;
    while (queue_pop(a, &c)) {
        switch ((AuroraCommandType)c.type) {
            case CMD_NOTE_ON: aurora_start_note(a, c.a, c.b, c.c); break;
            case CMD_NOTE_OFF: aurora_release_note(a, c.a, c.b); break;
            case CMD_ALL_OFF: all_notes_off_now(a); break;
            case CMD_TEMPO:
                a->bpm = (uint16_t)(c.u16 < 30u ? 30u : (c.u16 > 240u ? 240u : c.u16));
                set_step_period(a); break;
            case CMD_SWING:
                a->swing = (uint8_t)(c.a > 50u ? 50u : c.a); set_step_period(a); break;
            case CMD_MASTER: a->master = aurora_clampf(c.x, 0.0f, 1.0f); break;
            case CMD_TRACK:
                if (c.a < AURORA_TRACKS) {
                    a->tracks[c.a].preset = (uint8_t)(c.b % AURORA_PRESET_COUNT);
                    a->tracks[c.a].level = aurora_clampf(c.x, 0.0f, 1.0f);
                    a->tracks[c.a].pan = aurora_clampf(c.y, -1.0f, 1.0f);
                }
                break;
            case CMD_TRACK_PRESET:
                if (c.a < AURORA_TRACKS) a->tracks[c.a].preset = (uint8_t)(c.b % AURORA_PRESET_COUNT);
                break;
            case CMD_TRACK_PATTERN:
                if (c.a < AURORA_TRACKS) a->tracks[c.a].pattern = (uint8_t)(c.b % AURORA_PATTERNS);
                break;
            case CMD_TRACK_LEVEL:
                if (c.a < AURORA_TRACKS) a->tracks[c.a].level = aurora_clampf(c.x, 0.0f, 1.0f);
                break;
            case CMD_TRACK_PAN:
                if (c.a < AURORA_TRACKS) a->tracks[c.a].pan = aurora_clampf(c.x, -1.0f, 1.0f);
                break;
            case CMD_STEP:
                if (c.a < AURORA_TRACKS && c.b < AURORA_PATTERNS && c.c < AURORA_STEPS) {
                    AuroraStep *s = &a->patterns[c.a][c.b].step[c.c];
                    s->note = c.d; s->velocity = (uint8_t)c.x;
                    s->gate = (uint8_t)c.y; s->probability = (uint8_t)c.z;
                }
                break;
            case CMD_CLEAR_PATTERN:
                if (c.a < AURORA_TRACKS && c.b < AURORA_PATTERNS) {
                    uint32_t i;
                    for (i = 0; i < AURORA_STEPS; ++i) {
                        AuroraStep *s = &a->patterns[c.a][c.b].step[i];
                        s->note = 255u; s->velocity = 0u; s->gate = 75u; s->probability = 100u;
                    }
                }
                break;
            case CMD_SONG_EVENT:
                if (c.a < AURORA_TRACKS && c.b < AURORA_SONG_EVENTS) {
                    a->tracks[c.a].song[c.b].pattern = (uint8_t)(c.c & 15u);
                    a->tracks[c.a].song[c.b].repeats = (uint8_t)(c.d ? c.d : 1u);
                }
                break;
            case CMD_SONG_LENGTH:
                if (c.a < AURORA_TRACKS) {
                    a->tracks[c.a].song_length = (uint8_t)(c.b > AURORA_SONG_EVENTS ? AURORA_SONG_EVENTS : c.b);
                    a->tracks[c.a].song_position = 0u;
                    a->repeat_count[c.a] = 0u;
                }
                break;
            case CMD_SONG_MODE: a->song_mode = c.a ? 1u : 0u; break;
            case CMD_FX:
                a->delay_mix = aurora_clampf(c.x, 0.0f, 1.0f);
                a->reverb_mix = aurora_clampf(c.y, 0.0f, 1.0f);
                a->chorus_mix = aurora_clampf(c.z, 0.0f, 1.0f);
                a->drive = aurora_clampf(c.w, 0.0f, 1.0f);
                break;
            case CMD_PLAY:
                a->playing = 1u; a->step_index = 63u; a->step_remaining = 0u;
                memset(a->gate_remaining, 0, sizeof(a->gate_remaining));
                memset(a->active_note, 255, sizeof(a->active_note));
                break;
            case CMD_STOP:
                a->playing = 0u; all_notes_off_now(a); break;
            default: break;
        }
    }
}

void aurora_advance_step(Aurora *a) {
    uint32_t t;
    a->step_index = (uint8_t)((a->step_index + 1u) & 63u);
    set_step_period(a);
    a->step_remaining = a->step_base_frames;

    for (t = 0; t < AURORA_TRACKS; ++t) {
        AuroraPattern *pat = current_pattern(a, (uint8_t)t);
        AuroraStep *s = &pat->step[a->step_index];
        uint8_t probability = s->probability;
        if (a->active_note[t] != 255u && s->note != a->active_note[t]) {
            aurora_release_note(a, (uint8_t)t, a->active_note[t]);
            a->active_note[t] = 255u;
            a->gate_remaining[t] = 0u;
        }
        if (s->note != 255u && s->velocity && probability &&
            (aurora_random(a) % 100u) < probability) {
            if (a->active_note[t] != 255u) aurora_release_note(a, (uint8_t)t, a->active_note[t]);
            aurora_start_note(a, (uint8_t)t, s->note, s->velocity);
            a->active_note[t] = s->note;
            a->gate_remaining[t] = (a->step_base_frames * (uint32_t)(s->gate ? s->gate : 75u)) / 100u;
            if (!a->gate_remaining[t]) a->gate_remaining[t] = 1u;
        }
    }

    if (a->step_index == 63u && a->song_mode) {
        for (t = 0; t < AURORA_TRACKS; ++t) {
            AuroraTrack *tr = &a->tracks[t];
            if (tr->song_length) {
                AuroraSongEvent *e = &tr->song[tr->song_position];
                uint8_t reps = e->repeats ? e->repeats : 1u;
                if ((uint8_t)(a->repeat_count[t] + 1u) < reps) a->repeat_count[t]++;
                else {
                    a->repeat_count[t] = 0u;
                    tr->song_position = (uint8_t)((tr->song_position + 1u) % tr->song_length);
                }
            }
        }
    }
}

size_t aurora_instance_size(void) { return sizeof(Aurora); }

Aurora *aurora_init(void *memory, size_t bytes, const AuroraPlatform *platform) {
    Aurora *a;
    uint32_t t, p, s;
    if (!memory || bytes < sizeof(Aurora)) return NULL;
    a = (Aurora *)memory;
    memset(a, 0, sizeof(*a));
    if (platform) a->platform = *platform;
    a->core1_enabled = (a->platform.cpu1_submit && a->platform.cpu1_wait && a->platform.cpu1_retire) ? 1u : 0u;
    a->bpm = 118u; a->swing = 0u; a->master = 0.78f; a->rng = 0x1234ABCDu;
    a->delay_mix = 0.12f; a->reverb_mix = 0.18f; a->chorus_mix = 0.08f; a->drive = 0.05f;
    a->step_index = 63u;
    memset(a->active_note, 255, sizeof(a->active_note));
    aurora_dsp_init();
    aurora_build_presets(a);
    for (t = 0; t < AURORA_TRACKS; ++t) {
        a->tracks[t].preset = (uint8_t)(t * 7u);
        a->tracks[t].pattern = 0u;
        a->tracks[t].level = 0.78f;
        a->tracks[t].pan = (t & 1u) ? 0.18f : -0.18f;
        for (p = 0; p < AURORA_PATTERNS; ++p)
            for (s = 0; s < AURORA_STEPS; ++s) {
                a->patterns[t][p].step[s].note = 255u;
                a->patterns[t][p].step[s].velocity = 0u;
                a->patterns[t][p].step[s].gate = 75u;
                a->patterns[t][p].step[s].probability = 100u;
            }
        a->tracks[t].song[0].pattern = 0u;
        a->tracks[t].song[0].repeats = 1u;
    }
    set_step_period(a);
    return a;
}

void aurora_reset(Aurora *a) {
    if (!a) return;
    all_notes_off_now(a);
    a->playing = 0u; a->song_mode = 0u; a->step_index = 63u;
    a->step_remaining = 0u; a->voice_age = 0u;
    memset(a->delay, 0, sizeof(a->delay));
    memset(a->chorus_l, 0, sizeof(a->chorus_l));
    memset(a->chorus_r, 0, sizeof(a->chorus_r));
    memset(a->reverb, 0, sizeof(a->reverb));
    a->delay_pos = a->chorus_pos = 0u;
}

uint32_t aurora_core1_faults(const Aurora *a) { return a ? a->core1_faults : 0u; }
uint32_t aurora_core1_jobs(const Aurora *a) { return a ? a->core1_jobs : 0u; }
uint32_t aurora_command_drops(const Aurora *a) { return a ? a->commands.dropped : 0u; }
uint32_t aurora_render_overruns(const Aurora *a) { return a ? a->render_overruns : 0u; }
uint32_t aurora_active_voices(const Aurora *a) {
    uint32_t i, n = 0u; if (!a) return 0u;
    for (i = 0; i < AURORA_VOICES; ++i) if (a->voices[i].active) n++;
    return n;
}
int aurora_core1_enabled(const Aurora *a) { return a ? a->core1_enabled : 0; }
uint16_t aurora_get_tempo(const Aurora *a) { return a ? a->bpm : 0u; }
uint8_t aurora_get_swing(const Aurora *a) { return a ? a->swing : 0u; }
int aurora_get_track_settings(const Aurora *a, uint8_t track, uint8_t *preset, uint8_t *pattern, float *level, float *pan) {
    if (!a || track >= AURORA_TRACKS) return 0;
    if (preset) *preset = a->tracks[track].preset;
    if (pattern) *pattern = a->tracks[track].pattern;
    if (level) *level = a->tracks[track].level;
    if (pan) *pan = a->tracks[track].pan;
    return 1;
}
int aurora_get_fx(const Aurora *a, float *delay_mix, float *reverb_mix, float *chorus_mix, float *drive) {
    if (!a) return 0;
    if (delay_mix) *delay_mix = a->delay_mix;
    if (reverb_mix) *reverb_mix = a->reverb_mix;
    if (chorus_mix) *chorus_mix = a->chorus_mix;
    if (drive) *drive = a->drive;
    return 1;
}
int aurora_get_song_mode(const Aurora *a) { return a ? (int)a->song_mode : 0; }
uint8_t aurora_get_song_length(const Aurora *a, uint8_t track) {
    return a && track < AURORA_TRACKS ? a->tracks[track].song_length : 0u;
}
int aurora_get_preset_name(const Aurora *a, uint8_t preset, char *out, size_t capacity) {
    size_t n = 0;
    if (!a || !out || !capacity || preset >= AURORA_PRESET_COUNT) return 0;
    while (n + 1u < capacity && n + 1u < AURORA_NAME_LEN && a->presets[preset].name[n]) {
        out[n] = a->presets[preset].name[n];
        ++n;
    }
    out[n] = 0;
    return 1;
}

void aurora_set_tempo(Aurora *a, uint16_t bpm) { AuroraCommand c = {0}; if (!a) return; c.type=CMD_TEMPO; c.u16=bpm; queue_push(a,&c); }
void aurora_set_swing(Aurora *a, uint8_t percent) { AuroraCommand c = {0}; if (!a) return; c.type=CMD_SWING; c.a=percent; queue_push(a,&c); }
void aurora_set_master(Aurora *a, float volume) { AuroraCommand c = {0}; if (!a) return; c.type=CMD_MASTER; c.x=volume; queue_push(a,&c); }
void aurora_set_track(Aurora *a, uint8_t track, uint8_t preset, float level, float pan) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_TRACK; c.a=track; c.b=preset; c.x=level; c.y=pan; queue_push(a,&c);
}
void aurora_set_track_preset(Aurora *a, uint8_t track, uint8_t preset) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_TRACK_PRESET; c.a=track; c.b=preset; queue_push(a,&c);
}
void aurora_set_track_pattern(Aurora *a, uint8_t track, uint8_t pattern) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_TRACK_PATTERN; c.a=track; c.b=pattern; queue_push(a,&c);
}
void aurora_set_track_level(Aurora *a, uint8_t track, float level) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_TRACK_LEVEL; c.a=track; c.x=level; queue_push(a,&c);
}
void aurora_set_track_pan(Aurora *a, uint8_t track, float pan) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_TRACK_PAN; c.a=track; c.x=pan; queue_push(a,&c);
}
void aurora_set_step(Aurora *a, uint8_t track, uint8_t pattern, uint8_t step,
                     uint8_t note, uint8_t velocity, uint8_t gate, uint8_t probability) {
    AuroraCommand c = {0}; if (!a) return; c.type=CMD_STEP; c.a=track; c.b=pattern; c.c=step; c.d=note;
    c.x=(float)velocity; c.y=(float)gate; c.z=(float)probability; queue_push(a,&c);
}
void aurora_clear_pattern(Aurora *a, uint8_t track, uint8_t pattern) { AuroraCommand c={0}; if (!a) return; c.type=CMD_CLEAR_PATTERN; c.a=track; c.b=pattern; queue_push(a,&c); }
int aurora_get_step(const Aurora *a, uint8_t track, uint8_t pattern, uint8_t step, AuroraStep *out) {
    if (!a || !out || track >= AURORA_TRACKS || pattern >= AURORA_PATTERNS || step >= AURORA_STEPS) return 0;
    *out = a->patterns[track][pattern].step[step];
    return 1;
}
void aurora_set_song_event(Aurora *a, uint8_t track, uint8_t position, uint8_t pattern, uint8_t repeats) {
    AuroraCommand c={0}; if (!a) return; c.type=CMD_SONG_EVENT; c.a=track; c.b=position; c.c=pattern; c.d=repeats; queue_push(a,&c);
}
void aurora_set_song_length(Aurora *a, uint8_t track, uint8_t length) { AuroraCommand c={0}; if (!a) return; c.type=CMD_SONG_LENGTH; c.a=track; c.b=length; queue_push(a,&c); }
void aurora_set_song_mode(Aurora *a, int enabled) { AuroraCommand c={0}; if (!a) return; c.type=CMD_SONG_MODE; c.a=enabled?1u:0u; queue_push(a,&c); }
void aurora_play(Aurora *a) { AuroraCommand c={0}; if (!a) return; c.type=CMD_PLAY; queue_push(a,&c); }
void aurora_stop(Aurora *a) { AuroraCommand c={0}; if (!a) return; c.type=CMD_STOP; queue_push(a,&c); }
int aurora_is_playing(const Aurora *a) { return a ? a->playing : 0; }
void aurora_note_on(Aurora *a, uint8_t track, uint8_t note, uint8_t velocity) { AuroraCommand c={0}; if (!a) return; c.type=CMD_NOTE_ON; c.a=track; c.b=note; c.c=velocity; queue_push(a,&c); }
void aurora_note_off(Aurora *a, uint8_t track, uint8_t note) { AuroraCommand c={0}; if (!a) return; c.type=CMD_NOTE_OFF; c.a=track; c.b=note; queue_push(a,&c); }
void aurora_all_notes_off(Aurora *a) { AuroraCommand c={0}; if (!a) return; c.type=CMD_ALL_OFF; queue_push(a,&c); }
void aurora_set_fx(Aurora *a, float delay_mix, float reverb_mix, float chorus_mix, float drive) {
    AuroraCommand c={0}; if (!a) return; c.type=CMD_FX; c.x=delay_mix; c.y=reverb_mix; c.z=chorus_mix; c.w=drive; queue_push(a,&c);
}

static void render_chunk(Aurora *a, float *out, uint32_t frames) {
    uint32_t i;
    int worker_ok = 0;
    memset(a->mix_main, 0, (size_t)frames * 2u * sizeof(float));
    memset(a->mix_cpu1, 0, (size_t)frames * 2u * sizeof(float));
    if (a->core1_enabled && !a->core1_quarantined) {
        a->worker_frames = frames;
        a->worker_check++;
        if (!a->worker_check) a->worker_check = 1u;
        a->worker_done = 0u;
        if (a->platform.cpu1_submit(aurora_render_worker, a) > 0) {
            aurora_render_voice_range(a, 0u, AURORA_CORE0_VOICES, a->mix_main, frames);
            worker_ok = a->platform.cpu1_wait(AURORA_WORKER_TIMEOUT_US) > 0 &&
                        a->worker_done == a->worker_check;
        }
        if (!worker_ok) {
            int retired = a->platform.cpu1_retire() > 0;
            a->core1_faults++;
            a->render_overruns++;
            a->core1_enabled = 0u;
            if (retired) {
                /* Core 1 is parked and shared memory is safe again. */
                aurora_render_voice_range(a, AURORA_CORE0_VOICES, AURORA_VOICES, a->mix_main, frames);
            } else {
                /* Do not touch the worker-owned voice bank if core 1 did not park. */
                a->core1_quarantined = 1u;
            }
        }
    } else if (!a->core1_quarantined) {
        aurora_render_voice_range(a, 0u, AURORA_VOICES, a->mix_main, frames);
    } else {
        aurora_render_voice_range(a, 0u, AURORA_CORE0_VOICES, a->mix_main, frames);
    }
    for (i = 0; i < frames * 2u; ++i) {
        float s = a->mix_main[i] + (worker_ok ? a->mix_cpu1[i] : 0.0f);
        out[i] += s;
    }
    aurora_process_fx(a, out, frames);
}

void aurora_render(Aurora *a, float *stereo_out, uint32_t frames) {
    uint32_t pos = 0u;
    if (!a || !stereo_out || !frames) return;
    memset(stereo_out, 0, (size_t)frames * 2u * sizeof(float));
    aurora_apply_commands(a);
    while (pos < frames) {
        uint32_t chunk = aurora_min_u32(AURORA_BLOCK_FRAMES, frames - pos);
        uint32_t t;
        if (a->playing) {
            if (a->step_remaining == 0u) aurora_advance_step(a);
            chunk = aurora_min_u32(chunk, a->step_remaining ? a->step_remaining : 1u);
            for (t = 0; t < AURORA_TRACKS; ++t)
                if (a->gate_remaining[t]) chunk = aurora_min_u32(chunk, a->gate_remaining[t]);
        }
        if (!chunk) chunk = 1u;
        render_chunk(a, stereo_out + 2u * pos, chunk);
        pos += chunk;
        if (a->playing) {
            if (a->step_remaining >= chunk) a->step_remaining -= chunk;
            else a->step_remaining = 0u;
            for (t = 0; t < AURORA_TRACKS; ++t) {
                if (a->gate_remaining[t]) {
                    if (a->gate_remaining[t] <= chunk) {
                        a->gate_remaining[t] = 0u;
                        if (a->active_note[t] != 255u) {
                            aurora_release_note(a, (uint8_t)t, a->active_note[t]);
                            a->active_note[t] = 255u;
                        }
                    } else a->gate_remaining[t] -= chunk;
                }
            }
        }
    }
}
