# AURORA FM1 — original workstation firmware engine

**Version:** 0.1.0  
**Target:** M-VAVE FM-1 / JieLi AC791N (pi32v2)  
**Status:** Portable engine + first FM-1 application adapter. Adapter tests pass locally; the actual fm1-base host/WebAssembly/device builds and physical-hardware validation have not yet been run. No flashable `.fwsc` is included.

AURORA is an original, compact groovebox/workstation engine written in C. It is not a Skiff, Felucca, or FM1 Open repackage. It has its own synthesis, preset generation, sequencer, song data model, effects, MIDI parser, project file format, and two-worker audio architecture.

## What is implemented

- **128 built-in presets** across six original synthesis engines: analog subtractive, 4-operator-style FM, additive/wavetable, plucked/resonator, tonewheel organ, and synthesized drums.
- **16-voice polyphony**, with voices 0–7 rendered on core 0 and voices 8–15 dispatched to core 1 when a platform worker is supplied.
- **Eight sequencer tracks**, 16 patterns per track, 64 steps per pattern, velocity, gate length, probability, tempo and swing.
- **Song arrangement:** each track has its own ordered list of pattern/repeat events.
- **Live note input** and a raw MIDI byte parser supporting note on/off, program change, volume, pan, all-notes-off, MIDI clock, and transport start/stop.
- **Effects:** per-voice low-pass/resonance, stereo chorus, feedback delay, four-line reverb, drive and master limiting.
- **Project serialization:** a versioned binary project image with CRC32 validation.
- **Diagnostics:** active voices, core-1 jobs/faults, and render-overrun counters.

## Build and run the host version

Requirements: CMake 3.16+ and a C11 compiler. On Windows, use Visual Studio 2019 or newer with the CMake workload. On Linux, use GCC or Clang plus pthread support.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

Render a 34-second example song to stereo 16-bit PCM WAV:

```sh
./build/aurora_render aurora_demo.wav
```

On Windows, the executable is normally `build/Release/aurora_render.exe` or `build/aurora_render.exe`, depending on the CMake generator.

The tested host build reports an engine-state size of 162,712 bytes. The first FM-1 adapter reserves a fixed engine buffer in the platform pool and currently runs all voices on CPU0. It deliberately does not enable CPU1: the host worker is only a simulation, not a proven device worker. The adapter still needs a linked target RAM/stack audit and real render-time measurements against the FM-1 audio deadline.

## Embedding the engine

The engine does not allocate memory internally. The board application provides an aligned memory block:

```c
size_t bytes = aurora_instance_size();
void *memory = board_allocate_audio_state(bytes);
AuroraPlatform platform = {
    .cpu1_submit = board_cpu1_submit,
    .cpu1_wait = board_cpu1_wait,
    .cpu1_retire = board_cpu1_retire,
    .user = board_context
};
Aurora *engine = aurora_init(memory, bytes, &platform);
```

If the callbacks are all absent, the engine renders all 16 voices on core 0. If the worker is enabled but misses its bounded deadline, AURORA requests a safe retirement. If core 1 confirms it is parked, voices return to core 0. If it cannot confirm that, AURORA quarantines the worker-owned voice bank rather than risk concurrent memory access.

The audio callback calls:

```c
aurora_render(engine, stereo_float_buffer, frame_count);
```

Use 256-frame blocks at 44.1 kHz for the configuration tested here. The function can also render smaller chunks, including chunks split at sequencer gate/step boundaries. Board code must convert the float stereo output to the exact sample format required by the FM-1 audio DMA.

Control functions enqueue bounded commands; call them from one control/MIDI producer and let the audio callback consume them. The queue holds 1,023 pending commands. A full queue drops new commands; monitor this in a production port using `aurora_command_drops()` and expose it in the UI.

## Project save/load

Call `aurora_stop()`, render at least one block so the queued stop is applied, then use:

```c
size_t n = aurora_project_blob_size();
void *blob = board_allocate(n);
int written = aurora_project_export(engine, blob, n);
/* write exactly `written` bytes to the FM-1's project storage */

/* later */
int ok = aurora_project_import(engine, blob, n);
```

The export/import functions are synchronous snapshots. Do not call them while the audio callback is accessing the project model. The board port must supply the actual flash/file-storage layer.

## MIDI

Feed each received MIDI byte to `aurora_midi_feed(engine, &parser, byte, now_ms)`. MIDI channels 1–8 map to sequencer tracks 1–8; channels 9–16 wrap to the same eight tracks. Program changes select one of the 128 presets. CC 7 sets track level and CC 10 sets pan.

## FM-1 application adapter and remaining validation

A first application adapter now lives in [`fm1/`](fm1/README.md). It targets `charlesvestal/fm1-base` and its `felucca-bsp` submodule, using the upstream platform's existing startup, audio callback, key/encoder, MIDI, display, storage and package infrastructure. A local fake-platform harness checks audio conversion, keybed/MIDI routing, UI controls, song-event editing, project persistence and A/B recovery. The project mirror uses fm1-base's no-libm single-precision routines on target.

This is **not yet a complete device firmware image**. The JieLi PI32v2 compiler and matching AC79 SDK assets were not present in the build environment, so the fm1-base target linker, loader, package checks and `.fwsc` creation have not been run. The upstream fm1-base host simulator and WebAssembly emulator builds have not been run either. No physical FM-1 is available to verify cold boot, DMA output, flash wear/power-loss behavior or timing. CPU0-only 16-voice rendering still needs a target timing measurement; CPU1 stays disabled until a real safe worker integration is justified and tested.

Do not try to flash the host executable or rename anything to `.fwsc`. Do not flash the earlier experimental package mentioned in [`docs/FM1_PORTING.md`](docs/FM1_PORTING.md); it was not AURORA firmware. Follow [`fm1/README.md`](fm1/README.md) for the separate host, browser emulator and device-build paths and the required pre-flash precautions.

## Source map

- `include/aurora.h` — public audio, sequencer, project and platform API
- `include/aurora_midi.h` — MIDI byte parser API
- `src/aurora.c` — transport, track/pattern/song engine, command queue, core split
- `src/dsp.c` — six synth engines, envelopes, voice filtering and master FX
- `src/presets.c` — the 128 built-in patch definitions
- `src/midi.c` — MIDI 1.0 parser and track routing
- `src/project.c` — project serialization and CRC32 validation
- `host/` — desktop worker simulation and WAV renderer
- `tests/` — host tests
- `fm1/` — first FM-1 app adapter, controls, MIDI, A/B project storage, local platform harness and upstream build instructions
