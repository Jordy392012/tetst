# AURORA FM-1 firmware port — build status

**Date:** 2026-11-06  
**Status:** First FM-1 application adapter and local regression tests are complete. **No device `.fwsc` has been built or validated.**

## What is in this source bundle

- The portable AURORA synth/sequencer engine and original preset bank.
- A first application adapter for `charlesvestal/fm1-base` / `felucca-bsp` in `fm1/`.
- 256-frame, 44.1 kHz callback adapter converting AURORA float output to signed 24-bit stereo.
- FM-1 keybed, controls, USB MIDI and TRS MIDI integration.
- First-pass display and controls for tracks, patterns, presets, tempo, effects, transport, step recording, song-event add/remove and save.
- Two alternating flash-project slots, with header-last commit, CRC/read-back verification and fallback to the previous valid project if the newest slot fails outer-record or inner-project validation.
- A local fake-platform/NOR-flash test harness and the upstream fm1-base host-simulator script (`fm1/tests/basic.txt`).
- Target math compatibility using fm1-base's `fastmath.h` instead of depending on target `libm`.

## Tests actually run in this workspace

| Test | Result |
|---|---|
| Local adapter harness with GCC | Pass |
| Local adapter harness with Clang | Pass |
| CMake Release build | Pass |
| Core CTest | 1/1 passed |
| Prior repeated-run regression | 100/100 adapter runs and 100/100 core test runs passed |

The adapter harness models the platform API and NOR flash behavior. It is not fm1-base's own simulator and does not execute the AC791N device binary. No claim is made about real-time audio performance.

## Why there is no `.fwsc` yet

This environment contains `/usr/bin/cc`, Clang and CMake, but does **not** contain:

- The JieLi PI32v2 target compiler (`pi32v2/bin/clang`) and matching toolchain directory (`pi32v2/` plus `common/`).
- The matching AC79 SDK files required by fm1-base's packager: `uboot.boot`, `cfg_tool.bin`, and `cfg/eq_cfg_hw.bin`.
- Emscripten (`emcc`) for the browser app emulator.
- Docker or Podman for the supported Linux/AMD64 toolchain container route.
- A local fm1-base/felucca-bsp checkout. A GitHub clone attempt failed because this workspace could not resolve `github.com`.

The fm1-base device builder uses the PI32v2 compiler, Felucca board startup/audio code, target linker and checks, loader and `.fwsc` packager. A real `.fwsc` cannot be produced by renaming the host executable, a WAV, or a generic ELF.

## Pinned build inputs

Use the toolchain and SDK revision required by the current fm1-base build; do not substitute the FM1 Open V14 ZIP's binary SDK libraries.

| Asset | SHA-256 |
|---|---|
| `jieli-linux-toolchains-20250324.1.tar.xz` | `f686586bcfb45e0f0bb27fd2b39c7a7f313cb4f0e88a66a14da621ffa8225958` |
| SDK `cpu/wl82/tools/uboot.boot` | `4e3b4c220dc96641cb5a723f41e68ce41d5261ae9434bb33fbd7f2c59976ded4` |
| SDK `cpu/wl82/tools/cfg_tool.bin` | `276579954f076886a6a7694f65dc71c034a63a2c204b76749065c0ac7b010d1b` |
| SDK `cpu/wl82/tools/cfg/eq_cfg_hw.bin` | `41167491bffed4651750719c973d2758adeb9021a5670d02d6a53c85ed80ea7d` |

Expected SDK tag: `AC79NN_SDK_V1.2.1_2023-12-13`.

## Build sequence once the target environment is available

Place `AURORA-FM1/` beside an `fm1-base/` checkout cloned with its `felucca-bsp` submodule:

```sh
git clone --recursive https://github.com/charlesvestal/fm1-base.git
export JIELI_TOOLCHAIN=/path/to/jieli-toolchain
export AC79_SDK=/path/to/AC79NN_SDK_V1.2.1_2023-12-13

python3 fm1-base/tools/build.py AURORA-FM1/fm1 --host
AURORA-FM1/fm1/build/host/aurora_host AURORA-FM1/fm1/tests/basic.txt AURORA-FM1/fm1/build/host
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --web
python3 fm1-base/tools/build.py AURORA-FM1/fm1
```

The final command is the device build. It should create `AURORA-FM1/fm1/build/aurora.fwsc` only after target compile, linker layout, memory/stack and RAM-call checks and package generation succeed. `--host` and `--web` are application/platform simulators; they are not full AC791N emulation.

## Full-chip emulator and physical FM-1 validation

When a genuine package exists, use the community [FM-1 Emulator](https://joakimeriksson.github.io/fm1-emu/): choose **Open .fwsc…**, select `aurora.fwsc`, press **Start**, and inspect the display, audio, keys, encoders and MIDI. It emulates the AC791N and boots firmware packages unchanged. Emulator speed/load below real-time can cause audio dropouts, and successful emulation is not a substitute for a physical-board test.

Before installing on a physical FM-1, make and verify a full flash backup and confirm the stock recovery path. Follow fm1-base's device-specific install prerequisites; some units need stock V15 restored before switching firmware. The first AURORA configuration deliberately leaves CPU1, Bluetooth and Wi-Fi disabled. CPU0 renders all 16 voices; worst-case 256-frame render time (about 5.8 ms at 44.1 kHz) is still unmeasured. Do not treat it as production-ready until hardware timing, cold boot, audio DMA, MIDI and flash/power-loss behavior are tested.

## Package warning

An earlier experimental `.fwsc` from the preceding attempt was only an AURORA-branded FM1 Open V14 baseline and **did not contain the AURORA engine**. Emulator resets were observed. **Do not flash that earlier file.** There is no new `.fwsc` in this bundle.
