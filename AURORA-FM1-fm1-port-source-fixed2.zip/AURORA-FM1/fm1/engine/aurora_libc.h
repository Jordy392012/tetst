#ifndef AURORA_FM1_LIBC_H
#define AURORA_FM1_LIBC_H

/* fm1-base's freestanding felucca-bsp libc ABI (chip/libc.c). On its
   32-bit target, size_t is unsigned int and these declarations match the
   platform's exact prototypes. Native host tests use the host's libc ABI. */
#if defined(__SIZEOF_POINTER__) && __SIZEOF_POINTER__ == 4
void *memset(void *dst, int value, unsigned bytes);
void *memcpy(void *dst, const void *src, unsigned bytes);
int memcmp(const void *lhs, const void *rhs, unsigned bytes);
#else
#include <string.h>
#endif

#endif
