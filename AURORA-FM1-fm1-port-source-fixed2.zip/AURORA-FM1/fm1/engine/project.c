#include "aurora_internal.h"

#define PROJECT_MAGIC 0x50525541u /* "AURP" in little endian */
#define PROJECT_VERSION 1u

typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t bytes;
    uint16_t bpm;
    uint8_t swing;
    uint8_t song_mode;
    float master;
    float delay_mix, reverb_mix, chorus_mix, drive;
    AuroraTrack tracks[AURORA_TRACKS];
    AuroraPattern patterns[AURORA_TRACKS][AURORA_PATTERNS];
    uint32_t crc32;
} AuroraProjectImage;

static uint32_t crc32_bytes(const uint8_t *data, size_t bytes) {
    uint32_t crc = 0xFFFFFFFFu;
    size_t i;
    for (i = 0; i < bytes; ++i) {
        uint32_t x = crc ^ data[i];
        uint32_t b;
        for (b = 0; b < 8u; ++b) x = (x >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(x & 1u));
        crc = x;
    }
    return ~crc;
}

size_t aurora_project_blob_size(void) { return sizeof(AuroraProjectImage); }

int aurora_project_export_prepare(const Aurora *a, void *destination, size_t bytes) {
    AuroraProjectImage *im = (AuroraProjectImage *)destination;
    if (!a || !destination || bytes < sizeof(AuroraProjectImage)) return 0;
    im->magic = PROJECT_MAGIC;
    im->version = PROJECT_VERSION;
    im->bytes = (uint16_t)sizeof(AuroraProjectImage);
    im->bpm = a->bpm;
    im->swing = a->swing;
    im->song_mode = a->song_mode;
    im->master = a->master;
    im->delay_mix = a->delay_mix;
    im->reverb_mix = a->reverb_mix;
    im->chorus_mix = a->chorus_mix;
    im->drive = a->drive;
    memcpy(im->tracks, a->tracks, sizeof(im->tracks));
    memcpy(im->patterns, a->patterns, sizeof(im->patterns));
    im->crc32 = 0u;
    return (int)sizeof(*im);
}

int aurora_project_export_seal(void *destination, size_t bytes) {
    AuroraProjectImage *im = (AuroraProjectImage *)destination;
    if (!im || bytes < sizeof(AuroraProjectImage) || im->magic != PROJECT_MAGIC ||
        im->version != PROJECT_VERSION || im->bytes != sizeof(*im)) return 0;
    im->crc32 = crc32_bytes((const uint8_t *)im, sizeof(*im) - sizeof(im->crc32));
    return 1;
}

int aurora_project_export(const Aurora *a, void *destination, size_t bytes) {
    int written = aurora_project_export_prepare(a, destination, bytes);
    if (!written || !aurora_project_export_seal(destination, (size_t)written)) return 0;
    return written;
}

int aurora_project_import(Aurora *a, const void *source, size_t bytes) {
    const AuroraProjectImage *im = (const AuroraProjectImage *)source;
    uint32_t expected;
    uint32_t actual;
    uint32_t t, p, s;
    if (!a || !source || bytes < sizeof(AuroraProjectImage)) return 0;
    if (im->magic != PROJECT_MAGIC || im->version != PROJECT_VERSION || im->bytes != sizeof(*im)) return 0;
    expected = im->crc32;
    actual = crc32_bytes((const uint8_t *)im, sizeof(*im) - sizeof(im->crc32));
    if (actual != expected) return 0;
    if (im->bpm < 30u || im->bpm > 240u || im->swing > 50u) return 0;
    if (!isfinite(im->master) || !isfinite(im->delay_mix) || !isfinite(im->reverb_mix) ||
        !isfinite(im->chorus_mix) || !isfinite(im->drive)) return 0;
    for (t = 0; t < AURORA_TRACKS; ++t) {
        if (im->tracks[t].preset >= AURORA_PRESET_COUNT || im->tracks[t].pattern >= AURORA_PATTERNS ||
            im->tracks[t].song_length > AURORA_SONG_EVENTS ||
            !isfinite(im->tracks[t].level) || !isfinite(im->tracks[t].pan)) return 0;
        for (p = 0; p < AURORA_SONG_EVENTS; ++p)
            if (p < im->tracks[t].song_length && im->tracks[t].song[p].pattern >= AURORA_PATTERNS) return 0;
        for (p = 0; p < AURORA_PATTERNS; ++p)
            for (s = 0; s < AURORA_STEPS; ++s) {
                const AuroraStep *st = &im->patterns[t][p].step[s];
                if (st->note != 255u && st->note > 127u) return 0;
                if (st->velocity > 127u || st->gate > 100u || st->probability > 100u) return 0;
            }
    }
    memcpy(a->tracks, im->tracks, sizeof(a->tracks));
    memcpy(a->patterns, im->patterns, sizeof(a->patterns));
    for (t = 0; t < AURORA_TRACKS; ++t) {
        a->tracks[t].level = aurora_clampf(a->tracks[t].level, 0.0f, 1.0f);
        a->tracks[t].pan = aurora_clampf(a->tracks[t].pan, -1.0f, 1.0f);
        a->tracks[t].song_position = 0u;
    }
    a->bpm = im->bpm;
    a->swing = im->swing;
    a->song_mode = im->song_mode ? 1u : 0u;
    a->master = aurora_clampf(im->master, 0.0f, 1.0f);
    a->delay_mix = aurora_clampf(im->delay_mix, 0.0f, 1.0f);
    a->reverb_mix = aurora_clampf(im->reverb_mix, 0.0f, 1.0f);
    a->chorus_mix = aurora_clampf(im->chorus_mix, 0.0f, 1.0f);
    a->drive = aurora_clampf(im->drive, 0.0f, 1.0f);
    a->playing = 0u;
    a->step_index = 63u;
    a->step_remaining = 0u;
    memset(a->voices, 0, sizeof(a->voices));
    memset(a->gate_remaining, 0, sizeof(a->gate_remaining));
    memset(a->active_note, 255, sizeof(a->active_note));
    memset(a->repeat_count, 0, sizeof(a->repeat_count));
    a->commands.tail = a->commands.head;
    a->commands.dropped = 0u;
    a->step_base_frames = (AURORA_SAMPLE_RATE * 60u) / ((uint32_t)a->bpm * 4u);
    return 1;
}
