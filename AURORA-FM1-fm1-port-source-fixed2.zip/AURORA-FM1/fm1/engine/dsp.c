#include "aurora_internal.h"

#define AURORA_SINE_BITS 11u
#define AURORA_SINE_SIZE (1u << AURORA_SINE_BITS)
static float sine_table[AURORA_SINE_SIZE + 1u];
static uint8_t sine_table_ready;

void aurora_dsp_init(void) {
    uint32_t i;
    if (sine_table_ready) return;
    for (i = 0; i <= AURORA_SINE_SIZE; ++i)
        sine_table[i] = sinf((float)i * (2.0f * AURORA_PI / (float)AURORA_SINE_SIZE));
    sine_table_ready = 1u;
}

static float phase_wrap(float p) {
    p -= (float)(int32_t)p;
    if (p < 0.0f) p += 1.0f;
    return p;
}

static float phase_sine(float p) {
    float x;
    uint32_t i;
    float f;
    p = phase_wrap(p);
    x = p * (float)AURORA_SINE_SIZE;
    i = (uint32_t)x;
    f = x - (float)i;
    return sine_table[i] + (sine_table[i + 1u] - sine_table[i]) * f;
}

static float noise_sample(AuroraVoice *v) {
    uint32_t x = v->noise_rng;
    if (x == 0u) x = 0x6D2B79F5u;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    v->noise_rng = x;
    return ((float)(x & 0x00FFFFFFu) / 8388607.5f) - 1.0f;
}

static float osc(float phase, uint8_t shape) {
    float p = phase_wrap(phase);
    switch (shape & 3u) {
        case 0: return phase_sine(p);
        case 1: return 1.0f - 4.0f * fabsf(p - 0.5f);
        case 2: return p < 0.5f ? 1.0f : -1.0f;
        default: return 2.0f * p - 1.0f;
    }
}

static void advance_phases(AuroraVoice *v, const float ratio[6]) {
    uint32_t i;
    for (i = 0; i < 6u; ++i) {
        v->phase[i] += v->base_freq * ratio[i] / (float)AURORA_SAMPLE_RATE;
        if (v->phase[i] >= 1.0f) v->phase[i] -= (float)(uint32_t)v->phase[i];
    }
}

static float synth_sample(AuroraVoice *v, const AuroraPreset *p) {
    float s = 0.0f;
    float t = v->age_seconds;
    const float two_pi = 2.0f * AURORA_PI;
    switch ((AuroraEngine)p->engine) {
        case AURORA_ENGINE_ANALOG: {
            float a = osc(v->phase[0], p->wave);
            float b = osc(v->phase[1], (uint8_t)((p->wave + 1u) & 3u));
            float sub = phase_sine(v->phase[2]);
            s = 0.54f * a + 0.31f * b + 0.15f * sub;
            break;
        }
        case AURORA_ENGINE_FM: {
            float m1 = phase_sine(v->phase[1]);
            float m2 = phase_sine(v->phase[2] + 0.17f * m1);
            float m3 = phase_sine(v->phase[3] + 0.11f * m2);
            float carrier = phase_sine(v->phase[0] + p->modulation * 0.075f * m3 + 0.12f * m1);
            float body = phase_sine(v->phase[4] + 0.18f * m2);
            s = 0.78f * carrier + 0.22f * body;
            break;
        }
        case AURORA_ENGINE_WAVETABLE: {
            float morph = 0.5f + 0.5f * phase_sine(0.25f + t * (0.22f + p->modulation * 0.08f));
            float h2 = 0.42f + 0.38f * morph;
            float h3 = 0.26f + 0.34f * (1.0f - morph);
            float h4 = 0.14f + 0.22f * morph;
            s = phase_sine(v->phase[0]) + h2 * phase_sine(v->phase[1]) +
                h3 * phase_sine(v->phase[2]) + h4 * phase_sine(v->phase[3]) +
                0.08f * phase_sine(v->phase[4]);
            s *= 0.58f;
            break;
        }
        case AURORA_ENGINE_PLUCK: {
            float decay = 1.0f / (1.0f + t * (1.0f + p->brightness * 1.7f));
            float partials = phase_sine(v->phase[0]) + 0.47f * phase_sine(v->phase[1]) +
                             0.23f * phase_sine(v->phase[2]) + 0.10f * phase_sine(v->phase[3]);
            float transient = (t < 0.025f) ? noise_sample(v) * (1.0f - t / 0.025f) * 0.22f : 0.0f;
            s = partials * decay * (0.62f + p->brightness * 0.14f) + transient;
            break;
        }
        case AURORA_ENGINE_ORGAN: {
            float draw1 = 0.55f + 0.35f * p->brightness;
            float draw2 = 0.28f + 0.22f * p->modulation / 5.0f;
            s = 0.38f * phase_sine(v->phase[0]) + draw1 * 0.22f * phase_sine(v->phase[1]) +
                draw2 * 0.18f * phase_sine(v->phase[2]) + 0.10f * phase_sine(v->phase[3]) +
                0.06f * phase_sine(v->phase[4]);
            break;
        }
        case AURORA_ENGINE_DRUMS: {
            float n = noise_sample(v);
            float env = 1.0f / (1.0f + t * (2.0f + p->modulation * 1.1f));
            if (v->note == 36u || v->note == 35u || (v->note >= 40u && v->note <= 48u)) {
                float bend = 1.0f + 4.0f / (1.0f + t * 20.0f);
                s = phase_sine(v->phase[0] * bend) * env;
            } else if (v->note == 38u || v->note == 40u || v->note == 37u) {
                float tone = phase_sine(v->phase[0]) / (1.0f + t * 20.0f);
                s = 0.62f * tone + 0.48f * n * env;
            } else {
                float hp = n - v->noise_lp;
                v->noise_lp += 0.16f * (n - v->noise_lp);
                s = hp * env * 0.9f;
            }
            break;
        }
        default: s = 0.0f; break;
    }
    (void)two_pi;
    return s;
}

static float envelope_sample(AuroraVoice *v, const AuroraPreset *p) {
    if (v->stage == ENV_ATTACK) {
        float step = 1.0f / (fmaxf(p->attack, 0.001f) * (float)AURORA_SAMPLE_RATE);
        v->env += step;
        if (v->env >= 1.0f) { v->env = 1.0f; v->stage = ENV_DECAY; }
    } else if (v->stage == ENV_DECAY) {
        float step = (1.0f - p->sustain) / (fmaxf(p->decay, 0.001f) * (float)AURORA_SAMPLE_RATE);
        v->env -= step;
        if (v->env <= p->sustain) {
            v->env = p->sustain;
            if (p->engine == AURORA_ENGINE_DRUMS && v->env < 0.01f) {
                v->active = 0u; v->stage = ENV_OFF;
            } else v->stage = ENV_SUSTAIN;
        }
    } else if (v->stage == ENV_RELEASE) {
        v->env -= v->release_step;
        if (v->env <= 0.0005f) { v->env = 0.0f; v->active = 0u; v->stage = ENV_OFF; }
    }
    return v->env;
}

void aurora_render_voice_range(Aurora *a, uint32_t first, uint32_t last,
                               float *out, uint32_t frames) {
    static const float ratios[6] = {1.0f, 2.0f, 3.0f, 4.0f, 0.5f, 1.5f};
    uint32_t vi, i;
    for (vi = first; vi < last; ++vi) {
        AuroraVoice *v = &a->voices[vi];
        const AuroraPreset *p;
        const AuroraTrack *track;
        float gain_l, gain_r, alpha;
        if (!v->active) continue;
        p = &a->presets[v->preset];
        track = &a->tracks[v->track];
        gain_l = v->velocity * (1.0f / 127.0f) * p->level * track->level * sqrtf((1.0f - track->pan) * 0.5f);
        gain_r = v->velocity * (1.0f / 127.0f) * p->level * track->level * sqrtf((1.0f + track->pan) * 0.5f);
        alpha = 1.0f - expf(-2.0f * AURORA_PI * aurora_clampf(p->cutoff, 80.0f, 18000.0f) / (float)AURORA_SAMPLE_RATE);
        for (i = 0; i < frames; ++i) {
            float env, raw, filtered, sample;
            if (!v->active) break;
            env = envelope_sample(v, p);
            if (!v->active) break;
            raw = synth_sample(v, p);
            /* A compact resonant-ish low-pass stage; per-voice state is independent. */
            v->filter += alpha * (raw - v->filter);
            v->filter2 += alpha * (v->filter - v->filter2);
            filtered = v->filter * (1.0f - p->resonance * 0.16f) +
                       (v->filter - v->filter2) * p->resonance * 0.45f;
            sample = filtered * env * gain_l;
            out[2u * i] += sample;
            out[2u * i + 1u] += filtered * env * gain_r;
            v->age_seconds += 1.0f / (float)AURORA_SAMPLE_RATE;
            advance_phases(v, ratios);
        }
    }
}

void aurora_render_worker(void *context) {
    Aurora *a = (Aurora *)context;
    uint32_t check;
    if (!a) return;
    check = a->worker_check;
    memset(a->mix_cpu1, 0, sizeof(a->mix_cpu1));
    aurora_render_voice_range(a, AURORA_CORE0_VOICES, AURORA_VOICES,
                              a->mix_cpu1, a->worker_frames);
    if (a->worker_check == check) {
        a->worker_done = check;
        a->core1_jobs++;
    }
}

void aurora_process_fx(Aurora *a, float *stereo, uint32_t frames) {
    uint32_t i;
    static const uint16_t comb_len[4] = {149u, 211u, 263u, 293u};
    float delay_feedback = 0.34f;
    for (i = 0; i < frames; ++i) {
        float l = stereo[2u * i];
        float r = stereo[2u * i + 1u];
        float mono = 0.5f * (l + r);
        float delayed = a->delay[a->delay_pos];
        float rv = 0.0f;
        float ch_l, ch_r, mod, drive;
        uint32_t k;
        a->delay[a->delay_pos] = mono + delayed * delay_feedback;
        a->delay_pos = (a->delay_pos + 1u) & (AURORA_DELAY_SAMPLES - 1u);
        l += delayed * a->delay_mix;
        r += delayed * a->delay_mix;

        for (k = 0; k < 4u; ++k) {
            uint16_t pos = a->reverb_pos[k];
            float tap = a->reverb[k][pos];
            a->reverb[k][pos] = mono + tap * (0.68f - 0.055f * (float)k);
            a->reverb_pos[k] = (uint16_t)((pos + 1u) % comb_len[k]);
            rv += tap * 0.25f;
        }
        l += rv * a->reverb_mix;
        r += rv * a->reverb_mix;

        mod = 0.5f + 0.5f * phase_sine((float)a->chorus_pos / 2048.0f);
        a->chorus_l[a->chorus_pos] = l;
        a->chorus_r[a->chorus_pos] = r;
        {
            uint32_t offset = 180u + (uint32_t)(mod * 110.0f);
            uint32_t read = (a->chorus_pos - offset) & (AURORA_CHORUS_SAMPLES - 1u);
            ch_l = a->chorus_l[read];
            ch_r = a->chorus_r[read];
        }
        a->chorus_pos = (a->chorus_pos + 1u) & (AURORA_CHORUS_SAMPLES - 1u);
        l = l * (1.0f - a->chorus_mix * 0.5f) + ch_l * a->chorus_mix * 0.5f;
        r = r * (1.0f - a->chorus_mix * 0.5f) + ch_r * a->chorus_mix * 0.5f;

        drive = 1.0f + a->drive * 8.0f;
        l = (l * drive) / (1.0f + fabsf(l * drive));
        r = (r * drive) / (1.0f + fabsf(r * drive));
        a->filter_l += 0.18f * (l - a->filter_l);
        a->filter_r += 0.18f * (r - a->filter_r);
        l = a->filter_l * a->master;
        r = a->filter_r * a->master;
        /* Final soft limiter. */
        stereo[2u * i] = l / (1.0f + fabsf(l));
        stereo[2u * i + 1u] = r / (1.0f + fabsf(r));
    }
}
