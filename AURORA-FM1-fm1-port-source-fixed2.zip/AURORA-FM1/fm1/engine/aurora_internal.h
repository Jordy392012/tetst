#ifndef AURORA_INTERNAL_H
#define AURORA_INTERNAL_H
#include "aurora.h"
#include <string.h>
#if defined(AURORA_FM1_PORT)
#include "fastmath.h" /* fm1-base/include: float-only, no-libm DSP routines */
#define powf  fm_powf
#define sinf  fm_sinf
#define fabsf fm_fabsf
#define fmaxf fm_maxf
#define sqrtf fm_sqrtf
#define expf  fm_expf
static inline int aurora_fm1_isfinite(float x)
{
    union { float f; uint32_t u; } bits;
    bits.f = x;
    return (bits.u & 0x7F800000u) != 0x7F800000u;
}
#ifdef isfinite
#undef isfinite
#endif
#define isfinite(x) aurora_fm1_isfinite((x))
#else
#include <math.h>
#endif

#define AURORA_PI 3.14159265358979323846f
#define AURORA_CMD_CAP 1024u
#define AURORA_DELAY_SAMPLES 16384u
#define AURORA_CHORUS_SAMPLES 2048u
#define AURORA_REVERB_SIZE 512u
#define AURORA_WORKER_TIMEOUT_US 3500u

typedef enum { ENV_OFF=0, ENV_ATTACK, ENV_DECAY, ENV_SUSTAIN, ENV_RELEASE } EnvStage;
typedef struct {
    float phase[6];
    float env;
    float filter;
    float filter2;
    float noise;
    float noise_lp;
    uint32_t noise_rng;
    float age_seconds;
    float release_step;
    float base_freq;
    uint32_t age;
    uint8_t active;
    uint8_t stage;
    uint8_t note;
    uint8_t velocity;
    uint8_t track;
    uint8_t preset;
    uint8_t reserved[2];
} AuroraVoice;

typedef enum {
    CMD_NOTE_ON=1, CMD_NOTE_OFF, CMD_ALL_OFF, CMD_TEMPO, CMD_SWING,
    CMD_MASTER, CMD_TRACK, CMD_TRACK_PRESET, CMD_TRACK_LEVEL, CMD_TRACK_PAN, CMD_STEP, CMD_CLEAR_PATTERN, CMD_SONG_EVENT,
    CMD_SONG_LENGTH, CMD_SONG_MODE, CMD_FX, CMD_PLAY, CMD_STOP, CMD_TRACK_PATTERN
} AuroraCommandType;
typedef struct {
    uint8_t type, a, b, c, d;
    uint16_t u16;
    float x, y, z, w;
} AuroraCommand;

typedef struct {
    AuroraCommand item[AURORA_CMD_CAP];
    volatile uint16_t head;
    volatile uint16_t tail;
    volatile uint32_t dropped;
} AuroraCommandQueue;

struct Aurora {
    AuroraPlatform platform;
    AuroraPreset presets[AURORA_PRESET_COUNT];
    AuroraVoice voices[AURORA_VOICES];
    AuroraTrack tracks[AURORA_TRACKS];
    AuroraPattern patterns[AURORA_TRACKS][AURORA_PATTERNS];
    AuroraCommandQueue commands;

    float mix_main[AURORA_BLOCK_FRAMES * 2u];
    float mix_cpu1[AURORA_BLOCK_FRAMES * 2u];
    uint32_t worker_frames;
    volatile uint32_t worker_check;
    volatile uint32_t worker_done;
    uint8_t core1_enabled;
    uint8_t core1_quarantined;
    uint8_t playing;
    uint8_t song_mode;
    uint8_t reserved0;
    uint32_t core1_faults;
    uint32_t core1_jobs;
    uint32_t render_overruns;
    uint32_t voice_age;
    uint32_t rng;

    uint16_t bpm;
    uint8_t swing;
    uint8_t step_index;
    uint32_t step_remaining;
    uint32_t step_base_frames;
    uint8_t repeat_count[AURORA_TRACKS];
    uint8_t active_note[AURORA_TRACKS];
    uint32_t gate_remaining[AURORA_TRACKS];

    float master;
    float delay_mix, reverb_mix, chorus_mix, drive;
    float delay[AURORA_DELAY_SAMPLES];
    uint32_t delay_pos;
    float chorus_l[AURORA_CHORUS_SAMPLES];
    float chorus_r[AURORA_CHORUS_SAMPLES];
    uint32_t chorus_pos;
    float reverb[4][AURORA_REVERB_SIZE];
    uint16_t reverb_pos[4];
    float filter_l, filter_r;
};

void aurora_build_presets(Aurora *a);
void aurora_apply_commands(Aurora *a);
void aurora_render_voice_range(Aurora *a, uint32_t first, uint32_t last,
                               float *out, uint32_t frames);
void aurora_render_worker(void *context);
void aurora_process_fx(Aurora *a, float *stereo, uint32_t frames);
void aurora_start_note(Aurora *a, uint8_t track, uint8_t note, uint8_t velocity);
void aurora_release_note(Aurora *a, uint8_t track, uint8_t note);
void aurora_advance_step(Aurora *a);
uint32_t aurora_random(Aurora *a);
void aurora_dsp_init(void);

static inline float aurora_clampf(float x, float lo, float hi) {
    return x < lo ? lo : (x > hi ? hi : x);
}
static inline uint32_t aurora_min_u32(uint32_t a, uint32_t b) { return a < b ? a : b; }

#endif
