#ifndef AURORA_FM1_MIDI_H
#define AURORA_FM1_MIDI_H
#include "aurora.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint8_t running_status;
    uint8_t data[2];
    uint8_t data_count;
    uint8_t data_needed;
    uint8_t clock_count;
    uint8_t reserved[3];
    uint32_t last_quarter_ms;
    uint32_t last_clock_ms;
    uint8_t have_quarter;
} AuroraMidiParser;

void aurora_midi_init(AuroraMidiParser *parser);
/* Feed one raw MIDI byte. Channel 1..8 map to sequencer tracks 1..8. */
void aurora_midi_feed(Aurora *a, AuroraMidiParser *parser, uint8_t byte, uint32_t now_ms);

#ifdef __cplusplus
}
#endif
#endif
