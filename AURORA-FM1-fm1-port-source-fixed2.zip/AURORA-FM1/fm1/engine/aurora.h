#ifndef AURORA_FM1_H
#define AURORA_FM1_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define AURORA_SAMPLE_RATE       44100u
#define AURORA_BLOCK_FRAMES      256u
#define AURORA_TRACKS            8u
#define AURORA_PATTERNS          16u
#define AURORA_STEPS             64u
#define AURORA_SONG_EVENTS       32u
#define AURORA_PRESET_COUNT      128u
#define AURORA_VOICES            16u
#define AURORA_CORE0_VOICES      8u
#define AURORA_CORE1_VOICES      8u
#define AURORA_NAME_LEN          24u

/* Six independent synthesis models. All are original, compact algorithms. */
typedef enum {
    AURORA_ENGINE_ANALOG = 0,
    AURORA_ENGINE_FM,
    AURORA_ENGINE_WAVETABLE,
    AURORA_ENGINE_PLUCK,
    AURORA_ENGINE_ORGAN,
    AURORA_ENGINE_DRUMS,
    AURORA_ENGINE_COUNT
} AuroraEngine;

typedef struct {
    char name[AURORA_NAME_LEN];
    uint8_t engine;
    uint8_t wave;
    uint8_t character;
    uint8_t reserved;
    float attack;
    float decay;
    float sustain;
    float release;
    float cutoff;
    float resonance;
    float brightness;
    float modulation;
    float detune;
    float drive;
    float level;
} AuroraPreset;

typedef struct {
    uint8_t note;          /* 0..127; 255 means rest */
    uint8_t velocity;      /* 0..127 */
    uint8_t gate;           /* 1..100 percent of a step */
    uint8_t probability;    /* 0..100 */
} AuroraStep;

typedef struct {
    AuroraStep step[AURORA_STEPS];
} AuroraPattern;

typedef struct {
    uint8_t pattern;        /* 0..15 */
    uint8_t repeats;        /* 1..16 */
} AuroraSongEvent;

typedef struct {
    uint8_t preset;
    uint8_t pattern;
    uint8_t song_length;
    uint8_t song_position;
    float level;
    float pan;              /* -1..+1 */
    AuroraSongEvent song[AURORA_SONG_EVENTS];
} AuroraTrack;

/* Hardware abstraction. Implement these three callbacks in the AC791N port.
   submit() must queue one job on core 1; wait() must be bounded; retire() must
   park core 1 and guarantee that the job no longer touches shared memory. */
typedef void (*AuroraWorkerFn)(void *context);
typedef struct {
    int (*cpu1_submit)(AuroraWorkerFn fn, void *context);
    int (*cpu1_wait)(uint32_t timeout_us);
    int (*cpu1_retire)(void);
    void *user;
} AuroraPlatform;

typedef struct Aurora Aurora;

/* A static, allocation-free engine instance. */
size_t aurora_instance_size(void);
Aurora *aurora_init(void *memory, size_t bytes, const AuroraPlatform *platform);
void aurora_reset(Aurora *a);

/* Preset bank: 128 deterministic, built-in patches; no sample ROM required. */
uint32_t aurora_preset_count(void);
int aurora_get_preset(uint32_t index, AuroraPreset *out);
int aurora_get_preset_name(const Aurora *a, uint8_t preset, char *out, size_t capacity);

/* Project and pattern editing. */
void aurora_set_tempo(Aurora *a, uint16_t bpm);
void aurora_set_swing(Aurora *a, uint8_t percent);
void aurora_set_master(Aurora *a, float volume);
void aurora_set_track(Aurora *a, uint8_t track, uint8_t preset, float level, float pan);
void aurora_set_track_preset(Aurora *a, uint8_t track, uint8_t preset);
void aurora_set_track_pattern(Aurora *a, uint8_t track, uint8_t pattern);
void aurora_set_track_level(Aurora *a, uint8_t track, float level);
void aurora_set_track_pan(Aurora *a, uint8_t track, float pan);
void aurora_set_step(Aurora *a, uint8_t track, uint8_t pattern, uint8_t step,
                     uint8_t note, uint8_t velocity, uint8_t gate, uint8_t probability);
void aurora_clear_pattern(Aurora *a, uint8_t track, uint8_t pattern);
int aurora_get_step(const Aurora *a, uint8_t track, uint8_t pattern, uint8_t step, AuroraStep *out);
void aurora_set_song_event(Aurora *a, uint8_t track, uint8_t position,
                           uint8_t pattern, uint8_t repeats);
void aurora_set_song_length(Aurora *a, uint8_t track, uint8_t length);
void aurora_set_song_mode(Aurora *a, int enabled);

/* Transport and live performance. */
void aurora_play(Aurora *a);
void aurora_stop(Aurora *a);
int aurora_is_playing(const Aurora *a);
void aurora_note_on(Aurora *a, uint8_t track, uint8_t note, uint8_t velocity);
void aurora_note_off(Aurora *a, uint8_t track, uint8_t note);
void aurora_all_notes_off(Aurora *a);

/* Global FX controls. Mixes are 0..1. */
void aurora_set_fx(Aurora *a, float delay_mix, float reverb_mix,
                   float chorus_mix, float drive);

/* Render interleaved stereo float samples. Safe to call in fixed 256-frame blocks.
   The FM1 audio interrupt should call this from its audio/DMA deadline context. */
void aurora_render(Aurora *a, float *stereo_out, uint32_t frames);

/* Diagnostics. */
uint32_t aurora_core1_faults(const Aurora *a);
uint32_t aurora_core1_jobs(const Aurora *a);
uint32_t aurora_command_drops(const Aurora *a);
uint32_t aurora_render_overruns(const Aurora *a);
uint32_t aurora_active_voices(const Aurora *a);

/* Portable project image for flash/host storage. Stop transport and drain the
   audio command queue before export/import. The blob includes a CRC32. */
size_t aurora_project_blob_size(void);
/* Split snapshot creation from CRC sealing so embedded apps can copy the
   engine model while audio interrupts are locked, then calculate the checksum afterward. */
int aurora_project_export_prepare(const Aurora *a, void *destination, size_t bytes);
int aurora_project_export_seal(void *destination, size_t bytes);
int aurora_project_export(const Aurora *a, void *destination, size_t bytes);
int aurora_project_import(Aurora *a, const void *source, size_t bytes);
int aurora_core1_enabled(const Aurora *a);

/* Read-only state accessors for a UI. Call them from the main loop; the target
   app uses them at boot and for display, never to modify audio-owned state. */
uint16_t aurora_get_tempo(const Aurora *a);
uint8_t aurora_get_swing(const Aurora *a);
int aurora_get_track_settings(const Aurora *a, uint8_t track, uint8_t *preset,
                              uint8_t *pattern, float *level, float *pan);
int aurora_get_fx(const Aurora *a, float *delay_mix, float *reverb_mix,
                  float *chorus_mix, float *drive);
int aurora_get_song_mode(const Aurora *a);
uint8_t aurora_get_song_length(const Aurora *a, uint8_t track);

#ifdef __cplusplus
}
#endif
#endif
