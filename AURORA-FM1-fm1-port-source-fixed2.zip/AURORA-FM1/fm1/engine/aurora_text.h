#ifndef AURORA_FM1_TEXT_H
#define AURORA_FM1_TEXT_H

/* Tiny freestanding string helpers: no newlib/string.h dependency. */
static inline int aurora_text_equal(const char *a, const char *b)
{
    if (!a || !b) return a == b;
    while (*a && *a == *b) { ++a; ++b; }
    return *a == *b;
}

static inline void aurora_text_copy(char *dst, unsigned capacity, const char *src)
{
    unsigned i = 0;
    if (!dst || !capacity) return;
    if (src) while (src[i] && i + 1u < capacity) { dst[i] = src[i]; ++i; }
    dst[i] = 0;
}

#endif
