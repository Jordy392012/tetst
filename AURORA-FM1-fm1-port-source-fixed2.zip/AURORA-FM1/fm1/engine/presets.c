#include "aurora_internal.h"
#include "aurora_text.h"

static const char *const preset_names[AURORA_PRESET_COUNT] = {
    /* 00-23: ANALOG */
    "Velvet Keys", "Warm Saw", "Glass Poly", "Soft Brass", "Tape Strings", "Juno Mist",
    "Rubber Bass", "Round Sub", "Neon Lead", "Hollow Pluck", "Wide PWM", "Slow Sunrise",
    "Electric Silk", "Chime Pad", "Muted Pulse", "Blue Machine", "Analog Choir", "Deep Motion",
    "Mono Glide", "Amber Organ", "Soft Sync", "Night Brass", "Low Orbit", "Dream Sequence",
    /* 24-47: FM */
    "FM Bell Glass", "DX Marimba", "Crystal EP", "Tine Piano", "FM Celesta", "Metal Bloom",
    "Digital Harp", "Shimmer Bell", "FM Bass 01", "FM Bass 02", "Rubber FM", "Operator Stack",
    "Glass Mallet", "FM Brass", "Vox Pixels", "Ice Keys", "FM Guitar", "Tiny Chimes",
    "Bright EP", "Soft EP", "FM Pluck", "Hollow Metal", "Retro Data", "Starfield",
    /* 48-67: WAVETABLE */
    "Wavetable Air", "Morphing Pad", "Spectral Rain", "Digital Dawn", "Vowel Sweep", "Neon Choir",
    "Phase Garden", "Liquid Glass", "Granite Lead", "Wavetable Bass", "Slow Motion", "Cloud Atlas",
    "Frosted Keys", "Prism Arp", "Synthetic Reed", "Radiant Wash", "Harmonic Dust", "Future Brass",
    "Night Bloom", "Vector Pulse",
    /* 68-87: PLUCK */
    "Nylon Room", "Wooden Mallet", "Muted Guitar", "Kalimba Air", "Marimba Soft", "Picked Glass",
    "Pluck Sequence", "Cedar Strings", "Thumb Piano", "Tiny Harp", "Damped Steel", "Bamboo Pluck",
    "Bellwood", "Soft Banjo", "Hollow Kalimba", "String Pebbles", "Rain Drops", "Warm Mandolin",
    "Pluck Bass", "Resonant Wood",
    /* 88-103: ORGAN */
    "Jazz Drawbars", "Theatre Organ", "Soft Gospel", "Rotary Clean", "Smoke Organ", "Combo 60s",
    "Church Glass", "Muted B3", "Blue Note", "Organ Bass", "Slow Leslie", "Reed Organ",
    "Soul Machine", "Vintage Combo", "Air Cathedral", "Late Night Organ",
    /* 104-127: DRUMS */
    "Deep Kick", "Punch Kick", "Soft Kick", "808 Sub", "Acoustic Snare", "Tight Snare",
    "Brush Snare", "Clap Stack", "Closed Hat", "Open Hat", "Shaker", "Metal Ride",
    "Low Tom", "High Tom", "Analog Perc", "FM Perc", "Wood Block", "Rim Click",
    "Noise Sweep", "Laser Drum", "Break Kit", "Jazz Kit", "Dusty Kit", "Machine Kit"
};

static float unit(uint32_t x) { return (float)(x % 1000u) / 999.0f; }

static void build_preset_array(AuroraPreset *presets) {
    uint32_t i;
    for (i = 0; i < AURORA_PRESET_COUNT; ++i) {
        AuroraPreset *p = &presets[i];
        uint32_t local;
        uint32_t engine;
        if (i < 24u) { engine = AURORA_ENGINE_ANALOG; local = i; }
        else if (i < 48u) { engine = AURORA_ENGINE_FM; local = i - 24u; }
        else if (i < 68u) { engine = AURORA_ENGINE_WAVETABLE; local = i - 48u; }
        else if (i < 88u) { engine = AURORA_ENGINE_PLUCK; local = i - 68u; }
        else if (i < 104u) { engine = AURORA_ENGINE_ORGAN; local = i - 88u; }
        else { engine = AURORA_ENGINE_DRUMS; local = i - 104u; }

        memset(p, 0, sizeof(*p));
        aurora_text_copy(p->name, (unsigned)sizeof(p->name), preset_names[i]);
        p->engine = (uint8_t)engine;
        p->wave = (uint8_t)(local % 4u);
        p->character = (uint8_t)local;
        p->attack = 0.003f + unit(local * 97u + i * 13u) * 0.65f;
        p->decay = 0.04f + unit(local * 37u + i * 7u) * 1.4f;
        p->sustain = 0.18f + unit(local * 71u + 17u) * 0.78f;
        p->release = 0.06f + unit(local * 53u + i * 3u) * 2.2f;
        p->cutoff = 650.0f + unit(local * 131u + i * 19u) * 16000.0f;
        p->resonance = 0.04f + unit(local * 83u + 9u) * 0.55f;
        p->brightness = 0.15f + unit(local * 43u + 5u) * 1.1f;
        p->modulation = 0.08f + unit(local * 113u + 29u) * 5.5f;
        p->detune = (unit(local * 17u + 3u) - 0.5f) * 0.018f;
        p->drive = unit(local * 29u + 11u) * 0.45f;
        p->level = 0.62f + unit(local * 31u + 41u) * 0.32f;

        if (engine == AURORA_ENGINE_ANALOG) {
            if (local == 5u || local == 11u || local == 16u || local == 17u || local == 23u) p->attack += 0.5f;
            if (local == 6u || local == 7u || local == 8u || local == 18u) p->attack = 0.002f;
            p->cutoff = 500.0f + unit(local * 197u) * 11500.0f;
        } else if (engine == AURORA_ENGINE_FM) {
            p->attack *= 0.35f;
            p->decay *= 0.72f;
            p->modulation = 0.5f + unit(local * 79u + 1u) * 9.0f;
            p->brightness = 0.5f + unit(local * 61u) * 1.4f;
        } else if (engine == AURORA_ENGINE_WAVETABLE) {
            p->attack = 0.08f + unit(local * 101u) * 1.4f;
            p->release = 0.35f + unit(local * 23u) * 2.4f;
            p->modulation = 0.15f + unit(local * 97u) * 4.2f;
        } else if (engine == AURORA_ENGINE_PLUCK) {
            p->attack = 0.001f;
            p->decay = 0.18f + unit(local * 59u) * 1.6f;
            p->sustain = 0.04f + unit(local * 19u) * 0.24f;
            p->release = 0.1f + unit(local * 31u) * 0.8f;
            p->brightness = 0.3f + unit(local * 67u) * 1.2f;
        } else if (engine == AURORA_ENGINE_ORGAN) {
            p->attack = 0.003f;
            p->decay = 0.03f;
            p->sustain = 0.92f;
            p->release = 0.08f;
            p->modulation = 0.1f + unit(local * 47u) * 3.2f;
        } else {
            p->attack = 0.001f;
            p->decay = 0.05f + unit(local * 73u) * 0.9f;
            p->sustain = 0.0f;
            p->release = 0.02f;
            p->cutoff = 1200.0f + unit(local * 89u) * 15000.0f;
            p->modulation = 1.0f + unit(local * 41u) * 12.0f;
        }
    }
}

void aurora_build_presets(Aurora *a) { if (a) build_preset_array(a->presets); }

uint32_t aurora_preset_count(void) { return AURORA_PRESET_COUNT; }

int aurora_get_preset(uint32_t index, AuroraPreset *out) {
    AuroraPreset temp[AURORA_PRESET_COUNT];
    if (!out || index >= AURORA_PRESET_COUNT) return 0;
    build_preset_array(temp);
    *out = temp[index];
    return 1;
}
