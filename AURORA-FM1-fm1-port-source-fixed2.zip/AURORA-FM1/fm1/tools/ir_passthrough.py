#!/usr/bin/env python3
"""Identity LLVM-IR pass for fm1-base's stack checker.

Copy the generated IR byte-for-byte. fm1-base then compiles this unchanged IR
at the selected optimization level and emits optimized IR for stack analysis.
"""
from pathlib import Path
import shutil
import sys

if len(sys.argv) not in (3, 4):
    raise SystemExit("usage: ir_passthrough.py INPUT.ll OUTPUT.ll [UNIT]")

source = Path(sys.argv[1])
destination = Path(sys.argv[2])
destination.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(source, destination)
