#!/bin/sh
set -eu
APP=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT=$(CDPATH= cd -- "$APP/.." && pwd)
BASE=${FM1_BASE:-"$PROJECT/../fm1-base"}
PYTHON=${PYTHON:-python3}
MODE=${1:-help}
if [ ! -f "$BASE/tools/build.py" ]; then
  echo "fm1-base not found at: $BASE" >&2
  echo "Clone https://github.com/charlesvestal/fm1-base with --recursive, or set FM1_BASE." >&2
  exit 2
fi
case "$MODE" in
  host)
    "$PYTHON" "$BASE/tools/build.py" "$APP" --host
    exec "$APP/build/host/aurora_host" "$APP/tests/basic.txt" "$APP/build/host"
    ;;
  web)
    exec "$PYTHON" "$BASE/tools/build.py" "$APP" --web
    ;;
  firmware)
    # fm1-base is deliberately freestanding: use its own libc ABI rather than
    # importing newlib headers whose size_t prototypes conflict with chip/libc.c.
    exec "$PYTHON" "$BASE/tools/build.py" "$APP"
    ;;
  *)
    echo "Usage: $0 {host|web|firmware}" >&2
    exit 2
    ;;
esac
