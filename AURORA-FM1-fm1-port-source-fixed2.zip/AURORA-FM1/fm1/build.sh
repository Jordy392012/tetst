#!/bin/sh
set -eu
APP=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT=$(CDPATH= cd -- "$APP/.." && pwd)
BASE=${FM1_BASE:-"$PROJECT/../fm1-base"}
PYTHON=${PYTHON:-python3}
MODE=${1:-help}
if [ ! -f "$BASE/tools/build.py" ]; then
  echo "fm1-base not found at: $BASE" >&2
  echo "Clone https://github.com/charlesvestal/fm1-base with --recursive, or set FM1_BASE." >&2
  exit 2
fi
case "$MODE" in
  host)
    "$PYTHON" "$BASE/tools/build.py" "$APP" --host
    exec "$APP/build/host/aurora_host" "$APP/tests/basic.txt" "$APP/build/host"
    ;;
  web)
    exec "$PYTHON" "$BASE/tools/build.py" "$APP" --web
    ;;
  firmware)
    # PI32v2 does not bundle newlib's standard headers. fm1-base deliberately
    # accepts app-local device_include paths, so expose the matching SDK headers.
    SDK=${AC79_SDK:-"$HOME/fw-AC79_AIoT_SDK"}
    NEWLIB_HEADERS="$SDK/include_lib/newlib/include"
    if [ ! -d "$NEWLIB_HEADERS" ]; then
      echo "JieLi newlib headers not found: $NEWLIB_HEADERS" >&2
      exit 2
    fi
    rm -f "$APP/jieli_newlib_include"
    ln -s "$NEWLIB_HEADERS" "$APP/jieli_newlib_include"
    exec "$PYTHON" "$BASE/tools/build.py" "$APP"
    ;;
  *)
    echo "Usage: $0 {host|web|firmware}" >&2
    exit 2
    ;;
esac
