/* AURORA FM-1 application for charlesvestal/fm1-base. */
#pragma once
#include <stdint.h>
#include "plat.h"

#define APP_NAME "AURORA"
#define APP_VERSION "0.1.0-dev"
#define APP_BLOCK 256u
#define APP_CANVAS_PX (240u * 80u)
#define APP_TOUCH

/* The platform owns the panel-calibration object at its documented sector pair. */
enum { OBJ_PANEL, OBJ_NOBJ };
#define APP_STORE_MAP {0xDC000u}

void app_init(void);
void app_render(int32_t *lr, uint32_t n, uint32_t master_q12);
void app_panic(void);
void app_ui_init(void);
void app_frame(void);
void app_input_only(void);
void app_say(const char *a, const char *b);

/* Scriptable checks used by fm1-base's host simulator. */
#define APP_HOST_EXPECT
int app_expect(const char *what, int *got);
