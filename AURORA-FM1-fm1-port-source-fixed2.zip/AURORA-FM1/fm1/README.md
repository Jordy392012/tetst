# AURORA on the M-VAVE FM-1

This directory is the first application-level FM-1 port of the AURORA engine. It targets **`charlesvestal/fm1-base`** (which brings in `felucca-bsp` as a submodule). It does not use the FM1 Open firmware's closed synth binary.

## What this port currently does

- Runs the AURORA engine in the FM-1 audio callback and converts float stereo samples to signed 24-bit output.
- Maps the 27-key velocity-sensitive keybed to live notes and USB-MIDI note-on/note-off.
- Receives USB/TRS MIDI note, program-change, CC 7, CC 10 and all-notes-off messages. TRS input is echoed to USB.
- Exposes eight tracks, 16 patterns per track, preset and tempo selection, swing, delay/reverb/chorus, play/stop, step record, erase, octave shift and song-event add/remove.
- Saves the complete AURORA project image to two alternating flash slots. Each slot has a sequence number and CRC-protected header/payload; the older valid copy is retained until the new copy is read back successfully. The engine-state copy is made while audio interrupts are locked; the CRC pass runs after unlocking. The lock duration has not been measured on hardware.
- Uses CPU0 only in this first target pass. CPU1 is intentionally not enabled before a real target worker/retirement implementation and measured timing are available.

The source is designed to build through fm1-base's device, host and WebAssembly build paths. The local adapter test harness below verifies app callbacks, audio samples, input/MIDI routing, project save/reload and recovery from both a corrupted newest flash payload and a CRC-valid wrapper containing an invalid inner project. It is **not** a replacement for the upstream host simulator, WebAssembly build, device build, or hardware tests.

## Controls

| Control | Action |
| --- | --- |
| Keybed | Play live notes; with REC armed, enter notes into successive steps |
| SELECT encoder | Select track 1–8 |
| ALGO encoder or SEL button | Select pattern 1–16 |
| PRESET encoder | Select one of 128 presets for the selected track |
| K1 | Tempo, 30–240 BPM |
| K2 / K3 / K4 | Delay / reverb / chorus mix |
| PLAY | Start/stop sequencer |
| REC | Arm/disarm step recording |
| EDIT | Toggle erase mode while recording |
| SEQ | Toggle pattern/song playback mode |
| ENV | Append the selected pattern as the next song event for the selected track |
| LFO | Remove the final song event (keeps at least one) |
| ARP | Toggle swing between 0% and 25% |
| FX | Bypass/enable effects |
| GLO | All notes off |
| OCT− / OCT+ | Shift keybed octave down/up (limited to ±2) |
| SAVE | Stop transport, synchronize, then save the project to flash |
| HOME | Reset step cursor to step 1 |

The song arranger currently appends/removes one-repeat pattern events; it is not yet a full event editor. The app UI is deliberately a first playable interface rather than a finished product UI.

## Build against fm1-base

Use the current fm1-base checkout with its `bsp` submodule initialized. Keep this AURORA project and `fm1-base` in the same parent directory, for example:

```text
workspace/
  AURORA-FM1/       # this project
  fm1-base/         # https://github.com/charlesvestal/fm1-base, cloned --recursive
```

Then from the workspace:

```sh
git clone --recursive https://github.com/charlesvestal/fm1-base.git
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --host
AURORA-FM1/fm1/build/host/aurora_host AURORA-FM1/fm1/tests/basic.txt AURORA-FM1/fm1/build/host
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --web
```

The browser emulator files are written to `fm1/build/emu/`; serve that directory over HTTP and open its `index.html`. The browser build requires Emscripten (`emcc`). This fm1-base browser build is an app/platform simulator, not a full AC791N CPU emulator.

For a **full-chip test of the actual `.fwsc` package**, use the community [FM-1 Emulator](https://joakimeriksson.github.io/fm1-emu/). Once fm1-base has produced a real `aurora.fwsc`, select **Open .fwsc…**, choose that exact file, press **Start**, then test key input, controls, audio and project saving. The emulator runs firmware packages unchanged on an emulated AC791N; watch its speed/load readout because browser/device performance can cause audio dropouts. This emulator test is not a substitute for measuring worst-case timing and flash behavior on the physical unit.

For a device package, install the pinned JieLi PI32v2 toolchain and matching AC79 SDK checkout. Set `JIELI_TOOLCHAIN` to the extracted directory containing `pi32v2/` and `common/`, and set `AC79_SDK` to the SDK root (or pass `--sdk`). The expected SDK tag is `AC79NN_SDK_V1.2.1_2023-12-13`; verify the pinned hashes in [`docs/FM1_PORTING.md`](../docs/FM1_PORTING.md). Then run:

```sh
python3 fm1-base/tools/build.py AURORA-FM1/fm1
```

A successful device build should create `fm1/build/aurora.fwsc` and run fm1-base's image, link, RAM-call, and packaging checks. Do not install any package if a build check fails. The exact requirements and pinned file hashes are documented by fm1-base's Getting Started guide and `fm1-base/tools/build.py`.

`fm1.toml` currently describes a development build. A release build also needs the repository/site metadata and a genuine 240×240 or larger screenshot; do not make a release package by filling these fields with invented URLs or placeholder artwork.

## Local adapter tests (no FM-1 SDK required)

```sh
cd AURORA-FM1
./fm1/tests/run_target.sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

The adapter test uses a fake platform and NOR-flash model. Its fastmath stub is test-only; actual fm1-base host/device/WebAssembly builds use fm1-base's `include/fastmath.h` so the FM-1 path does not link `libm`.

## Important limitations before flashing

- This working tree has **not** been built into `aurora.fwsc` here: the JieLi PI32v2 toolchain and matching AC79 SDK files were not present in the build environment.
- The actual fm1-base `--host` simulator and `--web` WebAssembly emulator have not been run here; only the local adapter harness has been run.
- No physical FM-1 has been available for cold-boot, audio, MIDI, flash endurance or power-cycle tests.
- CPU0 currently renders all 16 voices. The 256-frame / 44.1-kHz callback is about 5.8 ms; target timing and worst-case voice/effect load remain unmeasured.
- Bluetooth MIDI is disabled in this initial build. USB MIDI and TRS MIDI input are enabled through the base platform.
- Before the first install, make a full device flash backup and verify the stock recovery procedure. If the device currently runs FM1 Open, check fm1-base's install guidance; some devices require stock V15 restored first.

**Do not flash the earlier experimental `.fwsc` from the previous attempt.** It did not contain the AURORA engine. Only use a newly generated package after the real fm1-base device build passes all checks and the package hash is confirmed.
