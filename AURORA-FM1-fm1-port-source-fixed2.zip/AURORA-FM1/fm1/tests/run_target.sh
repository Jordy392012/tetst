#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=$(CDPATH= cd -- "$HERE/.." && pwd)
ROOT=$(CDPATH= cd -- "$APP/.." && pwd)
OUT="$HERE/test_target"
CC=${CC:-cc}
"$CC" -std=c11 -O2 -Wall -Wextra -Wpedantic -DAURORA_FM1_PORT=1 \
  -include "$HERE/stubs/gfx.h" \
  -I"$HERE/stubs" -I"$APP" -I"$APP/engine" \
  "$HERE/test_target.c" "$APP/app.c" \
  "$APP/engine/aurora.c" "$APP/engine/dsp.c" "$APP/engine/presets.c" \
  "$APP/engine/project.c" "$APP/engine/midi.c" \
  -lm -o "$OUT"
"$OUT"
