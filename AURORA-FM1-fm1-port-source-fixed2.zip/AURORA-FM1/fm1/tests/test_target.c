#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "app.h"
#include "gfx.h"

static uint8_t flash_mem[0x100000];
static uint32_t now_ms;
static uint32_t buttons_state, keys_state;
static int32_t enc_delta[NE];
static uint32_t midi_out_count;
static uint32_t midi_out_last;
static uint32_t midi_in_queue[16];
static int midi_in_ports[16];
static uint32_t midi_in_head, midi_in_tail;
static int lock_depth;
test_font_t FONT_B, FONT_XS;

uint32_t plat_ms(void) { return now_ms; }
uint32_t plat_buttons(void) { return buttons_state; }
uint32_t plat_keys(void) { return keys_state; }
int32_t plat_enc(int role) { int32_t n=enc_delta[role]; enc_delta[role]=0; return n; }
uint32_t plat_master(void) { return 4096u; }
void plat_midi_send(uint32_t pkt, uint32_t to) { (void)to; midi_out_count++; midi_out_last=pkt; }
int plat_midi_in(uint32_t *pkt, int *port) {
    if (midi_in_head==midi_in_tail) return 0;
    *pkt=midi_in_queue[midi_in_tail&15u]; *port=midi_in_ports[midi_in_tail&15u]; midi_in_tail++; return 1;
}
void plat_leds(uint32_t b, uint32_t k) { (void)b; (void)k; }
void plat_glow(int on) { (void)on; }
uint32_t plat_lock(void) { lock_depth++; return (uint32_t)lock_depth; }
void plat_unlock(uint32_t flags) { (void)flags; if (lock_depth) lock_depth--; }
const uint8_t *plat_data(uint32_t off) {
    if (off < 0x97000u || off >= 0xE0000u) return 0;
    return &flash_mem[off];
}
int plat_data_erase(uint32_t off) {
    if ((off & 0xFFFu) || off < 0x97000u || off + 0x1000u > 0xE0000u) return -1;
    memset(&flash_mem[off], 0xFF, 0x1000u); return 0;
}
int plat_data_write(uint32_t off, const void *src, uint32_t n) {
    const uint8_t *p=(const uint8_t *)src; uint32_t i;
    if (!src || off < 0x97000u || off + n > 0xE0000u) return -1;
    for (i=0;i<n;i++) flash_mem[off+i] &= p[i];
    return 0;
}
void touch_on(int on) { (void)on; }
void touch_poll(void) {}
uint32_t touch_keys(void) { return keys_state; }
uint8_t touch_vel(uint32_t key) { (void)key; return 100u; }
uint8_t touch_vel_contact(uint32_t key) { (void)key; return 0u; }
void cv_begin(uint32_t w,uint32_t h,uint16_t bg) {(void)w;(void)h;(void)bg;}
int32_t cv_text(int32_t x,int32_t y,const test_font_t*f,const char*s,uint16_t c){(void)x;(void)y;(void)f;(void)s;(void)c;return 0;}
void cv_rect(int32_t x,int32_t y,int32_t w,int32_t h,uint16_t c){(void)x;(void)y;(void)w;(void)h;(void)c;}
void cv_blit(uint32_t x,uint32_t y){(void)x;(void)y;}
int ann_on(void){return 0;}
void ann_say(const char*s,int i,int f){(void)s;(void)i;(void)f;}
void text_cat(char*d,const char*s){if(d&&s)strcat(d,s);}


static uint32_t test_crc32(const uint8_t *data, uint32_t bytes)
{
    uint32_t crc = 0xFFFFFFFFu, i;
    for (i = 0; i < bytes; ++i) {
        uint32_t x = crc ^ data[i], b;
        for (b = 0; b < 8u; ++b)
            x = (x >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(x & 1u));
        crc = x;
    }
    return ~crc;
}

static uint32_t read_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void write_u32(uint8_t *p, uint32_t v)
{
    p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8);
    p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24);
}

static void reseal_outer_slot(uint32_t base)
{
    uint8_t *h = &flash_mem[base];
    uint8_t *payload = &flash_mem[base + 0x100u];
    uint32_t n = read_u32(h + 12u);
    write_u32(h + 16u, test_crc32(payload, n));
    write_u32(h + 20u, 0u);
    write_u32(h + 20u, test_crc32(h, 32u));
}

static void press_button(uint32_t bit) { buttons_state |= bit; app_input_only(); }
static void release_button(uint32_t bit) { buttons_state &= ~bit; app_input_only(); }
static void render_blocks(unsigned count) {
    int32_t block[256u*2u];
    unsigned b,i;
    for (b=0;b<count;b++) {
        memset(block,0,sizeof(block));
        app_render(block,256u,4096u);
        for (i=0;i<512u;i++) assert(block[i] >= -8388608 && block[i] <= 8388607);
        now_ms += 6u;
    }
}
static int expect(const char *what) { int got=-999; assert(app_expect(what,&got)); return got; }

int main(void)
{
    int32_t block[512];
    uint32_t i;
    memset(flash_mem,0xFF,sizeof(flash_mem));
    app_init();
    app_ui_init();
    assert(expect("track")==0);
    assert(expect("preset")==0);
    assert(expect("core1")==0); /* target adapter intentionally starts single-core */

    /* Keybed -> AURORA voice -> 24-bit FM-1 audio samples + USB MIDI. */
    keys_state=1u;
    app_input_only();
    assert(midi_out_count==1u);
    assert((midi_out_last & 0xFFu)==0x09u);
    render_blocks(8u);
    memset(block,0,sizeof(block));
    app_render(block,256u,4096u);
    for (i=0;i<512u;i++) assert(block[i] >= -8388608 && block[i] <= 8388607);
    {
        int nonzero=0;
        for (i=0;i<512u;i++) if (block[i] != 0) nonzero=1;
        assert(nonzero);
    }
    keys_state=0u;
    app_input_only();
    assert(midi_out_count==2u);
    assert(((midi_out_last >> 8) & 0xF0u)==0x80u);

    /* Track, pattern, patch and tempo controls. */
    enc_delta[EN_SELECT]=1;
    app_input_only();
    assert(expect("track")==1);
    enc_delta[EN_SELECT]=-1;
    enc_delta[EN_PRESET]=4;
    enc_delta[EN_K1]=12;
    app_input_only();
    assert(expect("track")==0);
    assert(expect("preset")==4);
    assert(expect("tempo")==130);
    press_button(1u<<B_SEL);
    assert(expect("pattern")==1);
    release_button(1u<<B_SEL);

    /* Arm step entry, enter a note, stop the command queue, then commit A/B. */
    press_button(1u<<B_REC);
    release_button(1u<<B_REC);
    keys_state=1u;
    app_input_only();
    assert(expect("record")==1);
    assert(expect("cursor")==1);
    keys_state=0u;
    app_input_only();
    press_button(1u<<B_SAVE);
    release_button(1u<<B_SAVE);
    render_blocks(2u);
    app_input_only();
    assert(expect("save_pending")==0);
    assert(expect("save_ok")==1);
    assert(memcmp(&flash_mem[0xA0000u], "AFM1", 4u)==0);

    /* Boot again from the saved flash image: project CRC, A/B header and state survive. */
    app_init();
    assert(expect("preset")==4);
    assert(expect("pattern")==1);
    assert(expect("song_events")==1);
    assert(expect("step0_note")==53);
    assert(expect("step0_velocity")==100);

    /* A second save goes to B; corrupting its payload must recover A. */
    press_button(1u<<B_ENV);
    release_button(1u<<B_ENV);
    assert(expect("song_events")==2);
    enc_delta[EN_PRESET]=1;
    app_input_only();
    assert(expect("preset")==5);
    press_button(1u<<B_SAVE);
    release_button(1u<<B_SAVE);
    render_blocks(2u);
    app_input_only();
    assert(expect("save_ok")==1);
    assert(memcmp(&flash_mem[0xAA000u], "AFM1", 4u)==0);
    flash_mem[0xAA000u + 0x100u + 17u] ^= 0x01u; /* simulate a damaged newest copy */
    app_init();
    assert(expect("preset")==4); /* older valid A survives */
    assert(expect("song_events")==1);
    assert(expect("step0_note")==53);
    press_button(1u<<B_ENV);
    release_button(1u<<B_ENV);
    assert(expect("song_events")==2);
    press_button(1u<<B_LFO);
    release_button(1u<<B_LFO);
    assert(expect("song_events")==1);

    /* A CRC-valid outer slot can still contain an invalid AURORA image.
       Re-seal the outer record after making its embedded BPM invalid; the
       loader must reject B semantically and recover A. */
    press_button(1u<<B_ENV);
    release_button(1u<<B_ENV);
    press_button(1u<<B_SAVE);
    release_button(1u<<B_SAVE);
    render_blocks(2u);
    app_input_only();
    assert(expect("save_ok")==1);
    flash_mem[0xAA000u + 0x100u + 8u] = 0u; /* BPM low byte: 118 -> 0 */
    reseal_outer_slot(0xAA000u);
    app_init();
    assert(expect("preset")==4);
    assert(expect("song_events")==1);

    /* TRS MIDI input routes by channel and is echoed only to USB. */
    midi_in_queue[midi_in_head&15u]=0x09u | (0x92u<<8) | (65u<<16) | (110u<<24);
    midi_in_ports[midi_in_head&15u]=PORT_TRS;
    midi_in_head++;
    app_input_only();
    assert(midi_out_count>=4u);
    render_blocks(4u);
    assert(expect("command_drops")==0);
    assert(expect("core1_faults")==0);

    app_frame();
    puts("AURORA FM-1 adapter tests passed");
    return 0;
}
