/* Test-only stand-in for fm1-base/include/fastmath.h.
   The real FM-1 build uses fm1-base's bit-exact, no-libm fastmath implementation. */
#pragma once
#include <math.h>
static inline float fm_fabsf(float x) { return fabsf(x); }
static inline float fm_maxf(float x, float y) { return x > y ? x : y; }
static inline float fm_powf(float x, float y) { return powf(x, y); }
static inline float fm_sinf(float x) { return sinf(x); }
static inline float fm_sqrtf(float x) { return sqrtf(x); }
static inline float fm_expf(float x) { return expf(x); }
