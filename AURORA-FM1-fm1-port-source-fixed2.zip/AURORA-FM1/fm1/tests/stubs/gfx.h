#pragma once
#include <stdint.h>
#define RGB(r,g,b) ((uint16_t)((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3)))
typedef struct { int unused; } test_font_t;
extern test_font_t FONT_B;
extern test_font_t FONT_XS;
void cv_begin(uint32_t w, uint32_t h, uint16_t bg);
int32_t cv_text(int32_t x, int32_t y, const test_font_t *f, const char *s, uint16_t c);
void cv_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c);
void cv_blit(uint32_t x, uint32_t y);
int ann_on(void);
void ann_say(const char *s, int ignored, int flags);
void text_cat(char *dst, const char *src);
#define ANN_NOW 1
