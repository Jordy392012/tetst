#pragma once
#include <stdint.h>
void touch_on(int on);
void touch_poll(void);
uint32_t touch_keys(void);
uint8_t touch_vel(uint32_t key);
uint8_t touch_vel_contact(uint32_t key);
