#pragma once
#include <stdint.h>
#include <stddef.h>
#define PLAT_HOST 1
#define PLAT_POOL
#define NKEYS 27
#define APP_BLOCK 256u
enum { B_FX, B_SEL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC, B_OCTDN, B_OCTUP, NB };
enum { EN_SELECT, EN_ALGO, EN_PRESET, EN_K1, EN_K2, EN_K3, EN_K4, NE };
enum { PORT_USB, PORT_BLE, PORT_TRS, NPORTS };
#define TO_USB (1u << PORT_USB)
#define LED_PLAY_GREEN (1u << NB)
static inline int32_t clamp(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }
uint32_t plat_ms(void);
uint32_t plat_buttons(void);
uint32_t plat_keys(void);
int32_t plat_enc(int role);
uint32_t plat_master(void);
void plat_midi_send(uint32_t pkt, uint32_t to);
int plat_midi_in(uint32_t *pkt, int *port);
void plat_leds(uint32_t buttons, uint32_t keys);
void plat_glow(int on);
uint32_t plat_lock(void);
void plat_unlock(uint32_t flags);
const uint8_t *plat_data(uint32_t offset);
int plat_data_erase(uint32_t offset);
int plat_data_write(uint32_t offset, const void *src, uint32_t bytes);
