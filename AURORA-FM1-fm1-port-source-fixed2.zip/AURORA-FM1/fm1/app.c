/*
 * AURORA FM-1 application adapter.
 * Copyright (c) 2026 AURORA FM1 contributors. MIT; see engine/LICENSE.
 * Platform layer: charlesvestal/fm1-base (MPL-2.0), linked at build time.
 */
#include <stdint.h>
#include <stddef.h>
#include "engine/aurora_libc.h"
#include "engine/aurora_text.h"
#include "app.h"
#include "touch.h"
#include "engine/aurora.h"

#define PROJECT_MAGIC       0x314D4641u /* "AFM1" */
#define PROJECT_VERSION     1u
#define PROJECT_SLOT_A      0x000A0000u
#define PROJECT_SLOT_B      0x000AA000u
#define PROJECT_SLOT_BYTES  0x0000A000u /* 40 KiB: ten sectors per A/B copy */
#define PROJECT_PAYLOAD_OFF 0x00000100u
#define PROJECT_BUFFER_MAX  0x00009000u
#define PROJECT_SECTOR      0x00001000u
#define AUDIO_MAX_FRAMES    AURORA_BLOCK_FRAMES
#define ENGINE_BUFFER_BYTES 180000u

/* The synth state, float block and project snapshot live in fm1-base's .pool,
   not .bss. The 240x80 canvas in app.h keeps total pool use modest. */
static union {
    uint32_t align[2];
    uint8_t bytes[ENGINE_BUFFER_BYTES];
} engine_storage PLAT_POOL;
static float render_scratch[AUDIO_MAX_FRAMES * 2u] PLAT_POOL;
static uint8_t project_scratch[PROJECT_BUFFER_MAX] PLAT_POOL;
static Aurora *engine;

/* The 32-byte commit record is written after the data. The old slot is never
   erased until the new slot has been checked successfully. */
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t header_bytes;
    uint32_t sequence;
    uint32_t payload_bytes;
    uint32_t payload_crc;
    uint32_t header_crc;
    uint8_t reserved[8];
} AuroraFm1ProjectHeader;
_Static_assert(sizeof(AuroraFm1ProjectHeader) == 32u, "project header layout");

static struct {
    uint32_t keys;
    uint32_t buttons;
    uint8_t key_track[NKEYS];
    uint8_t key_note[NKEYS];
    uint8_t preset[AURORA_TRACKS];
    uint8_t pattern[AURORA_TRACKS];
    uint8_t song_events[AURORA_TRACKS];
    int8_t octave;
    uint8_t track;
    uint8_t cursor;
    uint8_t recording;
    uint8_t erase_mode;
    uint8_t transport;
    uint8_t song_mode;
    uint8_t swing;
    uint8_t fx_bypass;
    uint16_t tempo;
    float delay_mix;
    float reverb_mix;
    float chorus_mix;
    float drive;
    char msg[2][24];
    uint32_t msg_until;
    uint8_t redraw;
} ui;

static volatile uint8_t save_pending;
static volatile uint8_t save_ready;
static volatile uint8_t save_blocks_left;
static volatile uint8_t audio_muted;
static uint8_t saved_slot = 0xFFu;
static uint32_t saved_sequence;
static uint8_t last_save_ok;

static uint32_t crc32_bytes(const uint8_t *p, size_t n)
{
    uint32_t crc = 0xFFFFFFFFu;
    size_t i;
    for (i = 0; i < n; ++i) {
        uint32_t x = crc ^ p[i];
        uint32_t b;
        for (b = 0; b < 8u; ++b)
            x = (x >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(x & 1u));
        crc = x;
    }
    return ~crc;
}

static uint32_t project_header_crc(const AuroraFm1ProjectHeader *h)
{
    AuroraFm1ProjectHeader t = *h;
    t.header_crc = 0u;
    return crc32_bytes((const uint8_t *)&t, sizeof(t));
}

static int project_slot_read(uint32_t base, AuroraFm1ProjectHeader *out)
{
    const uint8_t *hp = plat_data(base);
    const uint8_t *payload;
    AuroraFm1ProjectHeader h;
    size_t bytes = aurora_project_blob_size();
    if (!hp || !out || bytes > PROJECT_BUFFER_MAX ||
        bytes > PROJECT_SLOT_BYTES - PROJECT_PAYLOAD_OFF)
        return 0;
    memcpy(&h, hp, sizeof(h));
    if (h.magic != PROJECT_MAGIC || h.version != PROJECT_VERSION ||
        h.header_bytes != sizeof(h) || h.payload_bytes != bytes ||
        h.header_crc != project_header_crc(&h))
        return 0;
    payload = plat_data(base + PROJECT_PAYLOAD_OFF);
    if (!payload || crc32_bytes(payload, h.payload_bytes) != h.payload_crc)
        return 0;
    *out = h;
    return 1;
}

static int project_try_load(uint32_t base, const AuroraFm1ProjectHeader *h, uint8_t slot)
{
    const uint8_t *payload;
    if (!h)
        return 0;
    payload = plat_data(base + PROJECT_PAYLOAD_OFF);
    if (!payload || !aurora_project_import(engine, payload, h->payload_bytes))
        return 0;
    saved_slot = slot;
    saved_sequence = h->sequence;
    return 1;
}

static int project_load(void)
{
    AuroraFm1ProjectHeader a, b;
    int va = project_slot_read(PROJECT_SLOT_A, &a);
    int vb = project_slot_read(PROJECT_SLOT_B, &b);

    /* Prefer the newest complete copy, but also fall back if its inner AURORA
       image fails semantic validation despite a valid outer flash CRC. */
    if (va && vb) {
        if ((int32_t)(a.sequence - b.sequence) >= 0) {
            if (project_try_load(PROJECT_SLOT_A, &a, 0u)) return 1;
            if (project_try_load(PROJECT_SLOT_B, &b, 1u)) return 1;
        } else {
            if (project_try_load(PROJECT_SLOT_B, &b, 1u)) return 1;
            if (project_try_load(PROJECT_SLOT_A, &a, 0u)) return 1;
        }
    } else if (va) {
        if (project_try_load(PROJECT_SLOT_A, &a, 0u)) return 1;
    } else if (vb) {
        if (project_try_load(PROJECT_SLOT_B, &b, 1u)) return 1;
    }
    saved_slot = 0xFFu;
    saved_sequence = 0u;
    return 0;
}

static int project_slot_write(uint32_t base, uint32_t sequence, size_t bytes)
{
    AuroraFm1ProjectHeader h;
    size_t off;
    uint32_t sector;
    if (bytes == 0u || bytes > sizeof(project_scratch) ||
        bytes > PROJECT_SLOT_BYTES - PROJECT_PAYLOAD_OFF)
        return 0;

    /* Erase only the inactive slot. The previous valid project remains intact. */
    for (sector = 0; sector < PROJECT_SLOT_BYTES / PROJECT_SECTOR; ++sector)
        if (plat_data_erase(base + sector * PROJECT_SECTOR) != 0)
            return 0;

    /* Program in flash-page-sized chunks. Commit header is deliberately last. */
    for (off = 0; off < bytes; off += 256u) {
        uint32_t n = (uint32_t)(bytes - off);
        if (n > 256u) n = 256u;
        if (plat_data_write(base + PROJECT_PAYLOAD_OFF + (uint32_t)off,
                            project_scratch + off, n) != 0)
            return 0;
    }

    memset(&h, 0, sizeof(h));
    h.magic = PROJECT_MAGIC;
    h.version = PROJECT_VERSION;
    h.header_bytes = (uint16_t)sizeof(h);
    h.sequence = sequence;
    h.payload_bytes = (uint32_t)bytes;
    h.payload_crc = crc32_bytes(project_scratch, bytes);
    h.header_crc = project_header_crc(&h);
    if (plat_data_write(base, &h, sizeof(h)) != 0)
        return 0;

    /* Read back the commit and complete payload before declaring success. */
    {
        AuroraFm1ProjectHeader check;
        return project_slot_read(base, &check) && check.sequence == sequence;
    }
}

static void project_save_request(void)
{
    if (save_pending)
        return;
    if (ui.transport) {
        aurora_stop(engine);
        ui.transport = 0u;
    }
    save_pending = 1u;
    save_ready = 0u;
    save_blocks_left = 2u; /* drains control commands before the snapshot */
    app_say("SAVE", "STOPPING / SYNCING");
}

static void project_save_service(void)
{
    uint32_t irq;
    int exported;
    size_t bytes;
    uint32_t target;
    uint32_t next_sequence;
    if (!save_pending || !save_ready || !engine)
        return;
    bytes = aurora_project_blob_size();
    if (bytes > sizeof(project_scratch) || bytes > PROJECT_SLOT_BYTES - PROJECT_PAYLOAD_OFF) {
        last_save_ok = 0u;
        save_pending = save_ready = 0u;
        app_say("SAVE FAILED", "PROJECT TOO LARGE");
        return;
    }

    /* The audio ISR owns the engine while it renders. Snapshot under the
       platform interrupt lock for the model copy only; the CRC and all flash operations happen unlocked. */
    irq = plat_lock();
    if (aurora_is_playing(engine)) {
        plat_unlock(irq);
        save_ready = 0u;
        save_blocks_left = 1u;
        return;
    }
    exported = aurora_project_export_prepare(engine, project_scratch, sizeof(project_scratch));
    plat_unlock(irq);
    if (exported <= 0 || (size_t)exported != bytes ||
        !aurora_project_export_seal(project_scratch, (size_t)exported)) {
        last_save_ok = 0u;
        save_pending = save_ready = 0u;
        app_say("SAVE FAILED", "SNAPSHOT ERROR");
        return;
    }

    target = saved_slot == 0u ? PROJECT_SLOT_B : PROJECT_SLOT_A;
    next_sequence = saved_sequence + 1u;
    if (!next_sequence) next_sequence = 1u;
    if (project_slot_write(target, next_sequence, bytes)) {
        saved_slot = (target == PROJECT_SLOT_A) ? 0u : 1u;
        saved_sequence = next_sequence;
        last_save_ok = 1u;
        app_say("PROJECT SAVED", "A/B CHECK OK");
    } else {
        last_save_ok = 0u;
        app_say("SAVE FAILED", "OLD COPY KEPT");
    }
    save_pending = save_ready = 0u;
    save_blocks_left = 0u;
}

static uint8_t wrap_u8(int32_t value, uint8_t count)
{
    int32_t n = value % count;
    if (n < 0) n += count;
    return (uint8_t)n;
}

static void set_fx(void)
{
    if (ui.fx_bypass)
        aurora_set_fx(engine, 0.0f, 0.0f, 0.0f, 0.0f);
    else
        aurora_set_fx(engine, ui.delay_mix, ui.reverb_mix, ui.chorus_mix, ui.drive);
}

static void midi_send_note(uint8_t channel, uint8_t note, uint8_t velocity, int on)
{
    uint32_t status = (on && velocity) ? 0x90u : 0x80u;
    uint32_t cin = (status == 0x90u) ? 0x09u : 0x08u;
    uint32_t pkt = cin | ((status | (channel & 0x0Fu)) << 8) |
                   ((uint32_t)(note & 0x7Fu) << 16) |
                   ((uint32_t)(velocity & 0x7Fu) << 24);
    plat_midi_send(pkt, TO_USB);
}

static void midi_input(void)
{
    uint32_t pkt;
    int port;
    while (plat_midi_in(&pkt, &port)) {
        uint32_t status = (pkt >> 8) & 0xFFu;
        uint8_t d1 = (uint8_t)((pkt >> 16) & 0x7Fu);
        uint8_t d2 = (uint8_t)((pkt >> 24) & 0x7Fu);
        uint8_t kind = (uint8_t)(status & 0xF0u);
        uint8_t track = (uint8_t)((status & 0x0Fu) % AURORA_TRACKS);
        if (kind == 0x90u && d2) {
            aurora_note_on(engine, track, d1, d2);
        } else if (kind == 0x80u || (kind == 0x90u && !d2)) {
            aurora_note_off(engine, track, d1);
        } else if (kind == 0xC0u) {
            ui.preset[track] = d1;
            aurora_set_track_preset(engine, track, d1);
        } else if (kind == 0xB0u && d1 == 7u) {
            aurora_set_track_level(engine, track, (float)d2 / 127.0f);
        } else if (kind == 0xB0u && d1 == 10u) {
            aurora_set_track_pan(engine, track, ((float)d2 / 63.5f) - 1.0f);
        } else if (kind == 0xB0u && d1 == 123u) {
            aurora_all_notes_off(engine);
        }
        /* A TRS keyboard is echoed to the computer; USB input is not looped. */
        if (port == PORT_TRS)
            plat_midi_send(pkt, TO_USB);
    }
}

static void keys_input(uint32_t keys)
{
    uint32_t k;
    uint32_t pressed = keys & ~ui.keys;
    uint32_t released = ui.keys & ~keys;
    for (k = 0; k < NKEYS; ++k) {
        if (pressed & (1u << k)) {
            int32_t note_i = 53 + (int32_t)k + (int32_t)ui.octave * 12;
            uint8_t note = (uint8_t)clamp(note_i, 0, 127);
            uint8_t velocity = touch_vel(k);
            if (!velocity) velocity = touch_vel_contact(k);
            if (!velocity) velocity = 96u;
            ui.key_track[k] = ui.track;
            ui.key_note[k] = note;
            if (ui.recording && !ui.transport) {
                if (ui.erase_mode)
                    aurora_set_step(engine, ui.track, ui.pattern[ui.track], ui.cursor,
                                    255u, 0u, 75u, 100u);
                else
                    aurora_set_step(engine, ui.track, ui.pattern[ui.track], ui.cursor,
                                    note, velocity, 75u, 100u);
                ui.cursor = (uint8_t)((ui.cursor + 1u) & 63u);
            }
            aurora_note_on(engine, ui.track, note, velocity);
            midi_send_note(ui.track, note, velocity, 1);
        }
        if (released & (1u << k)) {
            aurora_note_off(engine, ui.key_track[k], ui.key_note[k]);
            midi_send_note(ui.key_track[k], ui.key_note[k], 0u, 0);
        }
    }
    ui.keys = keys;
}

static void buttons_input(uint32_t buttons)
{
    uint32_t down = buttons & ~ui.buttons;
    if (down & (1u << B_PLAY)) {
        if (ui.transport) {
            aurora_stop(engine);
            ui.transport = 0u;
            app_say("TRANSPORT", "STOP");
        } else {
            aurora_play(engine);
            ui.transport = 1u;
            app_say("TRANSPORT", "PLAY");
        }
    }
    if (down & (1u << B_REC)) {
        ui.recording ^= 1u;
        app_say(ui.recording ? "STEP RECORD" : "RECORD OFF", ui.erase_mode ? "ERASE MODE" : "NOTE MODE");
    }
    if (down & (1u << B_EDIT)) {
        ui.erase_mode ^= 1u;
        app_say(ui.erase_mode ? "ERASE MODE" : "NOTE MODE", ui.recording ? "RECORD ARMED" : "RECORD OFF");
    }
    if (down & (1u << B_SEL)) {
        ui.pattern[ui.track] = wrap_u8((int32_t)ui.pattern[ui.track] + 1, AURORA_PATTERNS);
        aurora_set_track_pattern(engine, ui.track, ui.pattern[ui.track]);
        ui.cursor = 0u;
    }
    if (down & (1u << B_HOME)) {
        ui.cursor = 0u;
        app_say("STEP CURSOR", "RESET TO 01");
    }
    if (down & (1u << B_SEQ)) {
        ui.song_mode ^= 1u;
        aurora_set_song_mode(engine, ui.song_mode);
        app_say("SEQUENCER", ui.song_mode ? "SONG MODE" : "PATTERN MODE");
    }
    if (down & (1u << B_ENV)) {
        uint8_t pos = ui.song_events[ui.track];
        if (pos < AURORA_SONG_EVENTS) {
            aurora_set_song_event(engine, ui.track, pos, ui.pattern[ui.track], 1u);
            ui.song_events[ui.track] = (uint8_t)(pos + 1u);
            aurora_set_song_length(engine, ui.track, ui.song_events[ui.track]);
            app_say("SONG EVENT ADDED", "CURRENT PATTERN");
        } else {
            app_say("SONG FULL", "32 EVENTS MAX");
        }
    }
    if (down & (1u << B_LFO)) {
        uint8_t count = ui.song_events[ui.track];
        if (count > 1u) {
            count--;
            ui.song_events[ui.track] = count;
            aurora_set_song_length(engine, ui.track, count);
            app_say("SONG EVENT", "LAST REMOVED");
        } else {
            app_say("SONG EVENT", "ONE EVENT MINIMUM");
        }
    }
    if (down & (1u << B_ARP)) {
        ui.swing = ui.swing ? 0u : 25u;
        aurora_set_swing(engine, ui.swing);
        app_say("SWING", ui.swing ? "25 PERCENT" : "OFF");
    }
    if (down & (1u << B_GLO)) {
        aurora_all_notes_off(engine);
        app_say("MIDI", "ALL NOTES OFF");
    }
    if (down & (1u << B_OCTDN)) {
        if (ui.octave > -2) ui.octave--;
        aurora_all_notes_off(engine);
    }
    if (down & (1u << B_OCTUP)) {
        if (ui.octave < 2) ui.octave++;
        aurora_all_notes_off(engine);
    }
    if (down & (1u << B_FX)) {
        ui.fx_bypass ^= 1u;
        set_fx();
        app_say("EFFECTS", ui.fx_bypass ? "BYPASSED" : "ENABLED");
    }
    if (down & (1u << B_SAVE))
        project_save_request();
    ui.buttons = buttons;
}

static void encoders_input(void)
{
    int32_t n;
    n = plat_enc(EN_SELECT);
    if (n) ui.track = wrap_u8((int32_t)ui.track + n, AURORA_TRACKS);
    n = plat_enc(EN_ALGO);
    if (n) {
        ui.pattern[ui.track] = wrap_u8((int32_t)ui.pattern[ui.track] + n, AURORA_PATTERNS);
        aurora_set_track_pattern(engine, ui.track, ui.pattern[ui.track]);
        ui.cursor = (uint8_t)(ui.cursor & 0x3Fu);
    }
    n = plat_enc(EN_PRESET);
    if (n) {
        ui.preset[ui.track] = wrap_u8((int32_t)ui.preset[ui.track] + n, AURORA_PRESET_COUNT);
        aurora_set_track_preset(engine, ui.track, ui.preset[ui.track]);
    }
    n = plat_enc(EN_K1);
    if (n) {
        int32_t tempo = (int32_t)ui.tempo + n;
        if (tempo < 30) tempo = 30;
        if (tempo > 240) tempo = 240;
        ui.tempo = (uint16_t)tempo;
        aurora_set_tempo(engine, ui.tempo);
    }
    n = plat_enc(EN_K2);
    if (n) {
        ui.delay_mix += (float)n * 0.02f;
        if (ui.delay_mix < 0.0f) ui.delay_mix = 0.0f;
        if (ui.delay_mix > 1.0f) ui.delay_mix = 1.0f;
        set_fx();
    }
    n = plat_enc(EN_K3);
    if (n) {
        ui.reverb_mix += (float)n * 0.02f;
        if (ui.reverb_mix < 0.0f) ui.reverb_mix = 0.0f;
        if (ui.reverb_mix > 1.0f) ui.reverb_mix = 1.0f;
        set_fx();
    }
    n = plat_enc(EN_K4);
    if (n) {
        ui.chorus_mix += (float)n * 0.02f;
        if (ui.chorus_mix < 0.0f) ui.chorus_mix = 0.0f;
        if (ui.chorus_mix > 1.0f) ui.chorus_mix = 1.0f;
        set_fx();
    }
}

static void input_poll(void)
{
    uint32_t keys, buttons;
    if (!engine || save_pending)
        return;
    touch_poll();
    keys = touch_keys();
    buttons = plat_buttons();
    keys_input(keys);
    buttons_input(buttons);
    if (save_pending)
        return;
    encoders_input();
    midi_input();
}

void app_init(void)
{
    AuroraPlatform no_worker = {0};
    size_t n = aurora_instance_size();
    uint32_t t;
    int loaded = 0;
    if (n > sizeof(engine_storage.bytes)) {
        engine = 0;
        return;
    }
    engine = aurora_init(engine_storage.bytes, sizeof(engine_storage.bytes), &no_worker);
    if (!engine)
        return;

    memset(&ui, 0, sizeof(ui));
    ui.track = 0u;
    ui.cursor = 0u;
    ui.octave = 0;
    ui.tempo = 118u;
    ui.swing = 0u;
    ui.delay_mix = 0.12f;
    ui.reverb_mix = 0.18f;
    ui.chorus_mix = 0.08f;
    ui.drive = 0.05f;
    saved_slot = 0xFFu;
    saved_sequence = 0u;
    for (t = 0; t < AURORA_TRACKS; ++t) {
        ui.preset[t] = (uint8_t)(t * 7u);
        ui.pattern[t] = 0u;
    }
    loaded = project_load();
    if (!loaded) {
        for (t = 0; t < AURORA_TRACKS; ++t) {
            aurora_set_song_event(engine, (uint8_t)t, 0u, 0u, 1u);
            aurora_set_song_length(engine, (uint8_t)t, 1u);
            ui.song_events[t] = 1u;
        }
    }
    ui.tempo = aurora_get_tempo(engine);
    ui.swing = aurora_get_swing(engine);
    ui.song_mode = (uint8_t)aurora_get_song_mode(engine);
    aurora_get_fx(engine, &ui.delay_mix, &ui.reverb_mix, &ui.chorus_mix, &ui.drive);
    for (t = 0; t < AURORA_TRACKS; ++t) {
        (void)aurora_get_track_settings(engine, (uint8_t)t, &ui.preset[t], &ui.pattern[t], 0, 0);
        ui.song_events[t] = loaded ? aurora_get_song_length(engine, (uint8_t)t) : 1u;
    }
    save_pending = save_ready = save_blocks_left = audio_muted = 0u;
    last_save_ok = 0u; /* no project has been saved by this session yet */
}

void app_render(int32_t *lr, uint32_t n, uint32_t master_q12)
{
    uint32_t done = 0u;
    const float scale = ((float)master_q12 / 4096.0f) * 8388607.0f;
    if (!lr)
        return;
    if (!engine || audio_muted) {
        uint32_t i;
        for (i = 0; i < n * 2u; ++i) lr[i] = 0;
        return;
    }
    while (done < n) {
        uint32_t frames = n - done;
        uint32_t i;
        if (frames > AUDIO_MAX_FRAMES) frames = AUDIO_MAX_FRAMES;
        aurora_render(engine, render_scratch, frames);
        for (i = 0; i < frames * 2u; ++i) {
            float v = render_scratch[i] * scale;
            if (!(v <= 8388607.0f && v >= -8388608.0f)) {
                if (v > 8388607.0f) v = 8388607.0f;
                else if (v < -8388608.0f) v = -8388608.0f;
                else v = 0.0f; /* NaN */
            }
            lr[2u * done + i] = (int32_t)v;
        }
        done += frames;
    }
    if (save_pending && save_blocks_left) {
        --save_blocks_left;
        if (!save_blocks_left)
            save_ready = 1u;
    }
}

void app_panic(void)
{
    audio_muted = 1u;
    save_pending = save_ready = save_blocks_left = 0u;
    if (engine)
        aurora_all_notes_off(engine);
}

void app_ui_init(void)
{
    touch_on(1);
    touch_poll();
    ui.keys = touch_keys();
    ui.buttons = plat_buttons();
    plat_glow(1);
    plat_leds(0u, ui.keys);
    app_say("AURORA", "FM-1 WORKSTATION");
}

void app_input_only(void)
{
    if (engine) {
        input_poll();
        project_save_service();
    }
}

typedef struct {
    char *data;
    size_t capacity;
    size_t length;
} AuroraTextBuf;

static void text_begin(AuroraTextBuf *b, char *dst, size_t capacity)
{
    b->data = dst;
    b->capacity = capacity;
    b->length = 0u;
    if (capacity) dst[0] = 0;
}

static void text_char(AuroraTextBuf *b, char c)
{
    if (b->capacity && b->length + 1u < b->capacity) {
        b->data[b->length++] = c;
        b->data[b->length] = 0;
    }
}

static void text_string(AuroraTextBuf *b, const char *s)
{
    if (s) while (*s) text_char(b, *s++);
}

static void text_unsigned(AuroraTextBuf *b, unsigned value, unsigned width)
{
    char digits[10];
    unsigned n = 0u;
    do {
        digits[n++] = (char)('0' + value % 10u);
        value /= 10u;
    } while (value && n < (unsigned)sizeof(digits));
    while (n < width && n < (unsigned)sizeof(digits)) digits[n++] = '0';
    while (n) text_char(b, digits[--n]);
}

static void text_signed_plus(AuroraTextBuf *b, int value)
{
    unsigned magnitude;
    if (value < 0) {
        text_char(b, '-');
        magnitude = (unsigned)(-(value + 1)) + 1u;
    } else {
        text_char(b, '+');
        magnitude = (unsigned)value;
    }
    text_unsigned(b, magnitude, 0u);
}

static void draw_top(void)
{
    char line[48];
    char patch[AURORA_NAME_LEN];
    cv_begin(240u, 80u, RGB(8, 10, 16));
    cv_text(7, 4, &FONT_B, "AURORA", RGB(230, 240, 255));
    {
        AuroraTextBuf b;
        text_begin(&b, line, sizeof(line));
        text_string(&b, "TRACK "); text_unsigned(&b, (unsigned)ui.track + 1u, 0u);
        text_string(&b, "/8    PATTERN "); text_unsigned(&b, (unsigned)ui.pattern[ui.track] + 1u, 2u);
        text_string(&b, "/16");
    }
    cv_text(7, 29, &FONT_XS, line, RGB(125, 195, 230));
    {
        AuroraTextBuf b;
        text_begin(&b, line, sizeof(line));
        text_unsigned(&b, (unsigned)ui.tempo, 0u); text_string(&b, " BPM   SWING ");
        text_unsigned(&b, (unsigned)ui.swing, 0u); text_string(&b, "%   ");
        text_string(&b, ui.song_mode ? "SONG" : "PATTERN");
    }
    cv_text(7, 44, &FONT_XS, line, RGB(210, 215, 225));
    if (!aurora_get_preset_name(engine, ui.preset[ui.track], patch, sizeof(patch)))
        patch[0] = 0;
    cv_text(7, 60, &FONT_XS, patch, RGB(240, 190, 110));
    cv_blit(0u, 0u);
}

static void draw_steps(void)
{
    uint32_t i, page = ui.cursor / 16u;
    uint32_t irq;
    AuroraStep visible[16];
    char title[40], label[8];

    /* The audio interrupt applies queued step edits. Take a short coherent
       snapshot rather than drawing across a partially-updated pattern. */
    irq = plat_lock();
    for (i = 0; i < 16u; ++i) {
        uint32_t step = page * 16u + i;
        if (!aurora_get_step(engine, ui.track, ui.pattern[ui.track],
                             (uint8_t)step, &visible[i])) {
            memset(&visible[i], 0, sizeof(visible[i]));
            visible[i].note = 255u;
        }
    }
    plat_unlock(irq);

    cv_begin(240u, 80u, RGB(12, 14, 21));
    {
        AuroraTextBuf b;
        text_begin(&b, title, sizeof(title));
        text_string(&b, "PATTERN STEPS  "); text_unsigned(&b, (unsigned)(page * 16u + 1u), 2u);
        text_char(&b, '-'); text_unsigned(&b, (unsigned)(page * 16u + 16u), 2u);
    }
    cv_text(7, 2, &FONT_XS, title, RGB(160, 190, 210));
    for (i = 0; i < 16u; ++i) {
        uint32_t step = page * 16u + i;
        int32_t x = 7 + (int32_t)(i % 4u) * 58;
        int32_t y = 17 + (int32_t)(i / 4u) * 15;
        const AuroraStep *s = &visible[i];
        uint16_t bg = RGB(30, 35, 45);
        uint16_t fg = RGB(130, 140, 155);
        if (s->note != 255u) { bg = RGB(33, 90, 78); fg = RGB(210, 250, 225); }
        if (step == ui.cursor) { bg = RGB(185, 105, 35); fg = RGB(255, 245, 220); }
        cv_rect(x, y, 52, 13, bg);
        {
            AuroraTextBuf b;
            text_begin(&b, label, sizeof(label));
            text_unsigned(&b, (unsigned)(step + 1u), 2u);
        }
        cv_text(x + 4, y + 1, &FONT_XS, label, fg);
        if (s->note != 255u)
            cv_rect(x + 34, y + 5, 13, 3, RGB(120, 220, 170));
    }
    cv_blit(0u, 80u);
}

static void draw_bottom(void)
{
    char line[48];
    cv_begin(240u, 80u, RGB(8, 10, 16));
    {
        AuroraTextBuf b;
        text_begin(&b, line, sizeof(line));
        text_string(&b, ui.transport ? "PLAY" : "STOP"); text_string(&b, "  ");
        text_string(&b, ui.recording ? (ui.erase_mode ? "ERASE" : "REC") : "REC OFF");
        text_string(&b, "  "); text_string(&b, ui.fx_bypass ? "FX BYPASS" : "FX ON");
    }
    cv_text(7, 5, &FONT_B, line, RGB(230, 235, 245));
    {
        AuroraTextBuf b;
        text_begin(&b, line, sizeof(line));
        text_string(&b, "OCTAVE "); text_signed_plus(&b, (int)ui.octave);
        text_string(&b, "   STEP "); text_unsigned(&b, (unsigned)ui.cursor + 1u, 2u);
        text_string(&b, "/64");
    }
    cv_text(7, 28, &FONT_XS, line, RGB(130, 195, 220));
    if (save_pending)
        cv_text(7, 47, &FONT_XS, "SAVING PROJECT - KEEP POWER ON", RGB(245, 190, 95));
    else if (ui.msg_until > plat_ms()) {
        cv_text(7, 47, &FONT_XS, ui.msg[0], RGB(240, 190, 110));
        cv_text(7, 62, &FONT_XS, ui.msg[1], RGB(190, 200, 210));
    } else {
        cv_text(7, 48, &FONT_XS, "KEYS: PLAY NOTES / REC: ENTER STEP", RGB(165, 175, 190));
        cv_text(7, 63, &FONT_XS, "ENCODERS: TRACK PATTERN PRESET TEMPO FX", RGB(165, 175, 190));
    }
    cv_blit(0u, 160u);
}

void app_frame(void)
{
    if (!engine)
        return;
    app_input_only();
    draw_top();
    draw_steps();
    draw_bottom();
    plat_leds((ui.transport ? (1u << B_PLAY) : 0u) |
              (ui.recording ? (1u << B_REC) : 0u), ui.keys);
}

void app_say(const char *a, const char *b)
{
    uint32_t i;
    for (i = 0; i < 23u && a && a[i]; ++i) ui.msg[0][i] = a[i];
    ui.msg[0][i] = 0;
    for (i = 0; i < 23u && b && b[i]; ++i) ui.msg[1][i] = b[i];
    ui.msg[1][i] = 0;
    ui.msg_until = plat_ms() + 1800u;
    ui.redraw = 1u;
    if (ann_on()) {
        char t[48];
        AuroraTextBuf b;
        text_begin(&b, t, sizeof(t));
        text_string(&b, ui.msg[0]);
        if (ui.msg[1][0]) { text_char(&b, ' '); text_string(&b, ui.msg[1]); }
        ann_say(t, 0, ANN_NOW);
    }
}

int app_expect(const char *what, int *got)
{
    if (!what || !got || !engine) return 0;
    if (aurora_text_equal(what, "track")) *got = ui.track;
    else if (aurora_text_equal(what, "pattern")) *got = ui.pattern[ui.track];
    else if (aurora_text_equal(what, "song_events")) *got = ui.song_events[ui.track];
    else if (aurora_text_equal(what, "preset")) *got = ui.preset[ui.track];
    else if (aurora_text_equal(what, "tempo")) *got = ui.tempo;
    else if (aurora_text_equal(what, "playing")) *got = ui.transport;
    else if (aurora_text_equal(what, "record")) *got = ui.recording;
    else if (aurora_text_equal(what, "cursor")) *got = ui.cursor;
    else if (aurora_text_equal(what, "voices")) *got = (int)aurora_active_voices(engine);
    else if (aurora_text_equal(what, "core1")) *got = aurora_core1_enabled(engine);
    else if (aurora_text_equal(what, "core1_faults")) *got = (int)aurora_core1_faults(engine);
    else if (aurora_text_equal(what, "command_drops")) *got = (int)aurora_command_drops(engine);
    else if (aurora_text_equal(what, "save_ok")) *got = last_save_ok;
    else if (aurora_text_equal(what, "save_pending")) *got = save_pending;
    else if (aurora_text_equal(what, "step0_note")) {
        AuroraStep step;
        if (!aurora_get_step(engine, ui.track, ui.pattern[ui.track], 0u, &step)) return 0;
        *got = step.note;
    }
    else if (aurora_text_equal(what, "step0_velocity")) {
        AuroraStep step;
        if (!aurora_get_step(engine, ui.track, ui.pattern[ui.track], 0u, &step)) return 0;
        *got = step.velocity;
    }
    else return 0;
    return 1;
}
