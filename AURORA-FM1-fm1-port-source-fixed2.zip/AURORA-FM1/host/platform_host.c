#define _POSIX_C_SOURCE 200809L
#include "host_platform.h"
#include <string.h>

AuroraHostWorker *g_aurora_host_worker = NULL;

#ifdef _WIN32
static DWORD WINAPI worker_thread(LPVOID arg) {
    AuroraHostWorker *w = (AuroraHostWorker *)arg;
    for (;;) {
        AuroraWorkerFn fn;
        void *ctx;
        EnterCriticalSection(&w->mutex);
        while (!w->pending && !w->shutdown) SleepConditionVariableCS(&w->cond, &w->mutex, INFINITE);
        if (w->shutdown) { LeaveCriticalSection(&w->mutex); break; }
        fn = w->fn; ctx = w->context;
        w->pending = 0; w->running = 1;
        LeaveCriticalSection(&w->mutex);
        if (fn) fn(ctx);
        EnterCriticalSection(&w->mutex);
        w->running = 0; w->complete = 1;
        WakeAllConditionVariable(&w->cond);
        LeaveCriticalSection(&w->mutex);
    }
    return 0;
}
static int host_submit(AuroraWorkerFn fn, void *context) {
    AuroraHostWorker *w = g_aurora_host_worker; int ok = 0; if (!w || !fn) return 0;
    EnterCriticalSection(&w->mutex);
    if (!w->retired && !w->pending && !w->running) {
        w->fn = fn; w->context = context; w->complete = 0; w->pending = 1;
        WakeConditionVariable(&w->cond); ok = 1;
    }
    LeaveCriticalSection(&w->mutex); return ok;
}
static int host_wait(uint32_t timeout_us) {
    AuroraHostWorker *w = g_aurora_host_worker; DWORD ms;
    if (!w) return 0;
    ms = (DWORD)((timeout_us + 999u) / 1000u);
    /* Desktop schedulers are not real-time. Keep the host simulation bounded,
       but do not mistake an ordinary thread scheduling delay for an FM-1 fault. */
    if (ms < 100u) ms = 100u;
    EnterCriticalSection(&w->mutex);
    while (!w->complete) {
        if (!SleepConditionVariableCS(&w->cond, &w->mutex, ms)) { LeaveCriticalSection(&w->mutex); return 0; }
    }
    w->complete = 0; LeaveCriticalSection(&w->mutex); return 1;
}
static int host_retire(void) {
    AuroraHostWorker *w = g_aurora_host_worker; if (!w) return 0;
    EnterCriticalSection(&w->mutex);
    while (w->pending || w->running) SleepConditionVariableCS(&w->cond, &w->mutex, INFINITE);
    w->retired = 1; LeaveCriticalSection(&w->mutex); return 1;
}
int aurora_host_platform_start(AuroraHostWorker *w, AuroraPlatform *p) {
    if (!w || !p) return 0; memset(w, 0, sizeof(*w));
    InitializeCriticalSection(&w->mutex); InitializeConditionVariable(&w->cond);
    g_aurora_host_worker = w; w->thread = CreateThread(NULL, 0, worker_thread, w, 0, NULL);
    if (!w->thread) { g_aurora_host_worker = NULL; DeleteCriticalSection(&w->mutex); return 0; }
    w->started = 1; p->cpu1_submit = host_submit; p->cpu1_wait = host_wait; p->cpu1_retire = host_retire; p->user = w; return 1;
}
void aurora_host_platform_stop(AuroraHostWorker *w) {
    if (!w || !w->started) return;
    EnterCriticalSection(&w->mutex); w->shutdown = 1; WakeAllConditionVariable(&w->cond); LeaveCriticalSection(&w->mutex);
    WaitForSingleObject(w->thread, INFINITE); CloseHandle(w->thread);
    if (g_aurora_host_worker == w) g_aurora_host_worker = NULL;
    DeleteCriticalSection(&w->mutex); w->started = 0;
}
#else
#include <time.h>
static void *worker_thread(void *arg) {
    AuroraHostWorker *w = (AuroraHostWorker *)arg;
    for (;;) {
        AuroraWorkerFn fn; void *ctx;
        pthread_mutex_lock(&w->mutex);
        while (!w->pending && !w->shutdown) pthread_cond_wait(&w->cond, &w->mutex);
        if (w->shutdown) { pthread_mutex_unlock(&w->mutex); break; }
        fn = w->fn; ctx = w->context; w->pending = 0; w->running = 1;
        pthread_mutex_unlock(&w->mutex);
        if (fn) fn(ctx);
        pthread_mutex_lock(&w->mutex); w->running = 0; w->complete = 1;
        pthread_cond_broadcast(&w->cond); pthread_mutex_unlock(&w->mutex);
    }
    return NULL;
}
static int host_submit(AuroraWorkerFn fn, void *context) {
    AuroraHostWorker *w = g_aurora_host_worker; int ok = 0; if (!w || !fn) return 0;
    pthread_mutex_lock(&w->mutex);
    if (!w->retired && !w->pending && !w->running) {
        w->fn = fn; w->context = context; w->complete = 0; w->pending = 1;
        pthread_cond_signal(&w->cond); ok = 1;
    }
    pthread_mutex_unlock(&w->mutex); return ok;
}
static int host_wait(uint32_t timeout_us) {
    AuroraHostWorker *w = g_aurora_host_worker; struct timespec deadline; int rc = 0; if (!w) return 0;
    if (timeout_us < 100000u) timeout_us = 100000u;
    clock_gettime(CLOCK_REALTIME, &deadline);
    deadline.tv_sec += (time_t)(timeout_us / 1000000u);
    deadline.tv_nsec += (long)(timeout_us % 1000000u) * 1000L;
    if (deadline.tv_nsec >= 1000000000L) { deadline.tv_sec++; deadline.tv_nsec -= 1000000000L; }
    pthread_mutex_lock(&w->mutex);
    while (!w->complete && !rc) rc = pthread_cond_timedwait(&w->cond, &w->mutex, &deadline);
    if (w->complete) { w->complete = 0; pthread_mutex_unlock(&w->mutex); return 1; }
    pthread_mutex_unlock(&w->mutex); return 0;
}
static int host_retire(void) {
    AuroraHostWorker *w = g_aurora_host_worker; if (!w) return 0;
    pthread_mutex_lock(&w->mutex);
    while (w->pending || w->running) pthread_cond_wait(&w->cond, &w->mutex);
    w->retired = 1; pthread_mutex_unlock(&w->mutex); return 1;
}
int aurora_host_platform_start(AuroraHostWorker *w, AuroraPlatform *p) {
    if (!w || !p) return 0; memset(w, 0, sizeof(*w));
    if (pthread_mutex_init(&w->mutex, NULL) != 0) return 0;
    if (pthread_cond_init(&w->cond, NULL) != 0) { pthread_mutex_destroy(&w->mutex); return 0; }
    g_aurora_host_worker = w;
    if (pthread_create(&w->thread, NULL, worker_thread, w) != 0) {
        g_aurora_host_worker = NULL; pthread_cond_destroy(&w->cond); pthread_mutex_destroy(&w->mutex); return 0;
    }
    w->started = 1; p->cpu1_submit = host_submit; p->cpu1_wait = host_wait; p->cpu1_retire = host_retire; p->user = w; return 1;
}
void aurora_host_platform_stop(AuroraHostWorker *w) {
    if (!w || !w->started) return;
    pthread_mutex_lock(&w->mutex); w->shutdown = 1; pthread_cond_broadcast(&w->cond); pthread_mutex_unlock(&w->mutex);
    pthread_join(w->thread, NULL);
    if (g_aurora_host_worker == w) g_aurora_host_worker = NULL;
    pthread_cond_destroy(&w->cond); pthread_mutex_destroy(&w->mutex); w->started = 0;
}
#endif
