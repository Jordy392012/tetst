#ifndef AURORA_HOST_PLATFORM_H
#define AURORA_HOST_PLATFORM_H
#include "aurora.h"
#ifdef _WIN32
#include <windows.h>
typedef struct {
    HANDLE thread;
    CRITICAL_SECTION mutex;
    CONDITION_VARIABLE cond;
    AuroraWorkerFn fn;
    void *context;
    int pending, running, complete, shutdown, retired, started;
} AuroraHostWorker;
#else
#include <pthread.h>
typedef struct {
    pthread_t thread;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    AuroraWorkerFn fn;
    void *context;
    int pending, running, complete, shutdown, retired, started;
} AuroraHostWorker;
#endif
int aurora_host_platform_start(AuroraHostWorker *worker, AuroraPlatform *platform);
void aurora_host_platform_stop(AuroraHostWorker *worker);
#endif
