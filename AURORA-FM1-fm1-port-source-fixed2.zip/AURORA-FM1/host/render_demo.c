#include "aurora.h"
#include "host_platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

static void put_u16(FILE *f, uint16_t x) { fputc(x & 255, f); fputc((x >> 8) & 255, f); }
static void put_u32(FILE *f, uint32_t x) {
    fputc(x & 255, f); fputc((x >> 8) & 255, f); fputc((x >> 16) & 255, f); fputc((x >> 24) & 255, f);
}
static void wav_header(FILE *f, uint32_t frames) {
    uint32_t data = frames * 4u;
    fwrite("RIFF", 1, 4, f); put_u32(f, 36u + data); fwrite("WAVE", 1, 4, f);
    fwrite("fmt ", 1, 4, f); put_u32(f, 16u); put_u16(f, 1u); put_u16(f, 2u);
    put_u32(f, AURORA_SAMPLE_RATE); put_u32(f, AURORA_SAMPLE_RATE * 4u);
    put_u16(f, 4u); put_u16(f, 16u); fwrite("data", 1, 4, f); put_u32(f, data);
}

static void build_demo(Aurora *a) {
    uint8_t i;
    aurora_set_tempo(a, 112u);
    aurora_set_swing(a, 9u);
    aurora_set_master(a, 0.78f);
    aurora_set_fx(a, 0.15f, 0.22f, 0.12f, 0.07f);
    /* Track 0: analog bass */
    aurora_set_track(a, 0, 6, 0.82f, -0.12f);
    aurora_set_step(a, 0, 0, 0, 36, 112, 82, 100);
    aurora_set_step(a, 0, 0, 8, 43, 104, 82, 100);
    aurora_set_step(a, 0, 0, 16, 41, 108, 82, 100);
    aurora_set_step(a, 0, 0, 24, 38, 106, 82, 100);
    aurora_set_step(a, 0, 0, 32, 36, 112, 82, 100);
    aurora_set_step(a, 0, 0, 40, 43, 104, 82, 100);
    aurora_set_step(a, 0, 0, 48, 41, 108, 82, 100);
    aurora_set_step(a, 0, 0, 56, 33, 106, 82, 100);
    /* Track 1: FM bell melody */
    aurora_set_track(a, 1, 24, 0.45f, 0.18f);
    { const uint8_t n[16] = {72, 76, 79, 83, 81, 79, 76, 74, 72, 76, 79, 84, 83, 79, 76, 74};
      for (i = 0; i < 16u; ++i) aurora_set_step(a, 1, 0, (uint8_t)(i * 4u), n[i], 84, 58, 96); }
    /* Track 2: plucked counterline */
    aurora_set_track(a, 2, 70, 0.40f, 0.32f);
    { const uint8_t n[8] = {60, 67, 64, 71, 62, 69, 65, 72};
      for (i = 0; i < 8u; ++i) aurora_set_step(a, 2, 0, (uint8_t)(i * 8u + 4u), n[i], 74, 42, 88); }
    /* Track 3: synthesized drum kit */
    aurora_set_track(a, 3, 104, 0.66f, 0.0f);
    for (i = 0; i < 64u; ++i) {
        if ((i % 16u) == 0u) aurora_set_step(a, 3, 0, i, 36, 118, 65, 100);
        else if ((i % 16u) == 8u) aurora_set_step(a, 3, 0, i, 38, 104, 58, 100);
        else if ((i % 4u) == 0u) aurora_set_step(a, 3, 0, i, 42, 58, 35, 94);
        else if ((i % 8u) == 6u) aurora_set_step(a, 3, 0, i, 46, 68, 35, 85);
    }
    /* Track 4: warm wavetable pad */
    aurora_set_track(a, 4, 52, 0.30f, -0.34f);
    aurora_set_step(a, 4, 0, 0, 48, 70, 95, 100);
    aurora_set_step(a, 4, 0, 16, 55, 70, 95, 100);
    aurora_set_step(a, 4, 0, 32, 52, 70, 95, 100);
    aurora_set_step(a, 4, 0, 48, 57, 70, 95, 100);
    /* Create a short song arrangement: pattern 0 repeated four times. */
    for (i = 0; i < 5u; ++i) {
        aurora_set_song_event(a, i, 0, 0, 4);
        aurora_set_song_length(a, i, 1);
    }
    aurora_set_song_mode(a, 1);
}

int main(int argc, char **argv) {
    const char *path = argc > 1 ? argv[1] : "aurora_demo.wav";
    const uint32_t bars = 16u;
    const uint32_t seconds = bars * 4u * 60u / 112u;
    const uint32_t total_frames = seconds * AURORA_SAMPLE_RATE;
    void *mem = NULL;
    Aurora *a;
    AuroraPlatform platform = {0};
    AuroraHostWorker worker;
    float *buffer;
    FILE *f;
    uint32_t done = 0u;

    mem = calloc(1u, aurora_instance_size());
    if (!mem) { fprintf(stderr, "engine allocation failed\n"); return 2; }
    if (!aurora_host_platform_start(&worker, &platform)) { fprintf(stderr, "worker startup failed\n"); free(mem); return 2; }
    a = aurora_init(mem, aurora_instance_size(), &platform);
    if (!a) { fprintf(stderr, "engine init failed\n"); aurora_host_platform_stop(&worker); free(mem); return 2; }
    build_demo(a);
    aurora_play(a);
    buffer = (float *)malloc((size_t)AURORA_BLOCK_FRAMES * 2u * sizeof(float));
    if (!buffer) { fprintf(stderr, "audio buffer allocation failed\n"); aurora_host_platform_stop(&worker); free(mem); return 2; }
    f = fopen(path, "wb");
    if (!f) { perror(path); free(buffer); aurora_host_platform_stop(&worker); free(mem); return 2; }
    wav_header(f, total_frames);
    while (done < total_frames) {
        uint32_t n = total_frames - done;
        uint32_t j;
        if (n > AURORA_BLOCK_FRAMES) n = AURORA_BLOCK_FRAMES;
        aurora_render(a, buffer, n);
        for (j = 0; j < n * 2u; ++j) {
            float x = buffer[j];
            int32_t q;
            if (x > 0.999f) x = 0.999f;
            if (x < -0.999f) x = -0.999f;
            q = (int32_t)lrintf(x * 32767.0f);
            put_u16(f, (uint16_t)(int16_t)q);
        }
        done += n;
    }
    fclose(f);
    printf("Rendered %s (%u frames, %u seconds)\n", path, total_frames, seconds);
    printf("Engine RAM state: %zu bytes | presets: %u | active voices at end: %u | core 1 jobs: %u | core 1 faults: %u\n",
           aurora_instance_size(), aurora_preset_count(), aurora_active_voices(a), aurora_core1_jobs(a), aurora_core1_faults(a));
    free(buffer);
    aurora_host_platform_stop(&worker);
    free(mem);
    return 0;
}
