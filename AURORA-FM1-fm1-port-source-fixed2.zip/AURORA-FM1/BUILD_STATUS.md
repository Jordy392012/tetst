# AURORA FM-1 build status

**Verification date:** 2026-11-06  
**Host platform:** Linux x86-64, GCC 14.2.0, CMake 3.31  
**Result:** portable engine tests and local FM-1 adapter tests pass; no target `.fwsc` or full upstream emulator build produced.

## Verified locally

- CMake Release build completed for `aurora`, `aurora_host`, `aurora_render`, and `aurora_tests`.
- Core CTest: 1/1 passed; the core test executable passed 100 consecutive direct runs in this port pass.
- The 256-frame, all-16-voice CPU0 regression path returned finite samples. This checks the portable fallback path, not the FM-1's real-time budget.
- A fresh 34-second stereo 16-bit / 44.1 kHz WAV demo was rendered; engine state size reported as 162,712 bytes.
- New `fm1/` application adapter compiled with a local fake platform. Tests covered signed 24-bit output bounds and nonzero audio, keybed notes and USB MIDI, TRS-to-USB routing, track/pattern/preset/tempo changes, step recording, song-event add/remove, project save/reload, recovery after an outer payload CRC failure, and fallback when the newest slot has a valid outer CRC but invalid inner AURORA project data.
- Adapter test executable passed 100 consecutive runs. The fake platform models NOR flash AND/write and sector erase behavior; it does not execute target hardware code.
- `fm1/engine/` carries the AURORA engine sources; its target-specific internal header selects fm1-base's no-libm `fastmath.h` implementation.

## Changes made in this pass

1. Added `fm1/app.c`, `app.h`, `fm1.toml`, `words.tsv`, build wrapper, local test harness and host simulator script. This is the first fm1-base application-level integration.
2. Added 24-bit audio callback conversion, FM-1 controls/keybed input, USB/TRS MIDI handling, a first-pass 240×240 interface and 2-slot CRC-protected project storage.
3. Split project serialization into a snapshot copy made with audio interrupts locked and a CRC seal performed after unlocking. The copy-lock duration has not been measured on hardware.
4. Kept CPU1, Bluetooth and Wi-Fi disabled. The device-side worker contract has not been proven; no desktop thread is treated as the FM-1 CPU1.
5. Added a no-libm compatibility layer for the FM-1 project mirror using fm1-base's single-precision fastmath routines.
6. Added fallback from an unusable newest project copy to the previous valid copy, including inner-project validation failure.
7. Updated the port documentation to distinguish implemented app-side integration from the unbuilt/unverified target image.

## Not available / not done

- The environment did not contain `emcc`, Docker/Podman, the JieLi PI32v2 target compiler, or the matching AC79 SDK files (`uboot.boot`, `cfg_tool.bin`, `cfg/eq_cfg_hw.bin`). Only the native `cc`, Clang and CMake toolchains were found.
- The fm1-base/felucca-bsp source checkout was not available as a local workspace, so the upstream `--host` and `--web` builds and test scripts could not be run here.
- **No AURORA `.fwsc` exists from this pass.** There is no target ELF, flash image, update loader, link map or output package to validate.
- No physical FM-1 was attached. Audio DMA format/underrun, app startup, UI, MIDI, flash endurance, cold boot and power-loss recovery remain unverified.
- CPU0 16-voice/effects render timing against the approximately 5.8 ms 256-frame audio period is unknown. CPU1 is off until a genuine worker/retirement integration is implemented and tested.
- The first-pass user interface and song editor are functional scaffolding; they are not a finished production instrument.

## Package safety

An earlier experimental `.fwsc` from the prior attempt was just a branded FM1 Open V14 baseline and did not include AURORA's engine. The emulator showed resets. **Do not flash that earlier file.** Do not rename host executables or build artifacts to `.fwsc`; only fm1-base's completed target packager can create the real device package.

## Next build commands

With fm1-base cloned recursively beside this project, Emscripten installed for the Web build, and the pinned JieLi PI32v2 toolchain plus AC79 assets configured for the device build:

```sh
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --host
AURORA-FM1/fm1/build/host/aurora_host AURORA-FM1/fm1/tests/basic.txt AURORA-FM1/fm1/build/host
python3 fm1-base/tools/build.py AURORA-FM1/fm1 --web
python3 fm1-base/tools/build.py AURORA-FM1/fm1
```

The full requirements and safe-install cautions are in `docs/FM1_PORTING.md` and `fm1/README.md`.
