#include "aurora.h"
#include "host_platform.h"
#include "aurora_midi.h"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

static int fake_submit(AuroraWorkerFn fn, void *context) { (void)fn; (void)context; return 1; }
static int fake_wait(uint32_t timeout_us) { (void)timeout_us; return 0; }
static int fake_retire(void) { return 1; }

int main(void) {
    void *mem = calloc(1u, aurora_instance_size());
    Aurora *a;
    AuroraPlatform platform = {0};
    AuroraHostWorker worker;
    AuroraPreset p;
    float audio[AURORA_BLOCK_FRAMES * 2u];
    uint32_t i;
    int nonzero = 0;
    AuroraMidiParser midi;
    void *project;
    size_t project_bytes;
    assert(mem != NULL);
    assert(aurora_preset_count() == 128u);
    for (i = 0; i < 128u; ++i) {
        int found = aurora_get_preset(i, &p);
        assert(found);
        assert(p.name[0] != '\0');
        assert(p.engine < AURORA_ENGINE_COUNT);
    }
    assert(!aurora_get_preset(128u, &p));
    {
        int started = aurora_host_platform_start(&worker, &platform);
        assert(started);
        if (!started) return 1;
    }
    a = aurora_init(mem, aurora_instance_size(), &platform);
    assert(a != NULL);
    aurora_set_track(a, 0u, 0u, 0.8f, 0.0f);
    for (i = 0; i < 12u; ++i) aurora_note_on(a, (uint8_t)(i % AURORA_TRACKS), (uint8_t)(48u + i), 100u);
    for (i = 0; i < 20u; ++i) {
        uint32_t j;
        aurora_render(a, audio, AURORA_BLOCK_FRAMES);
        for (j = 0; j < AURORA_BLOCK_FRAMES * 2u; ++j) {
            assert(isfinite(audio[j]));
            if (fabsf(audio[j]) > 0.00001f) nonzero = 1;
        }
    }
    assert(nonzero);
    /* Verify the public UI accessors and the pattern-select command. */
    aurora_set_song_event(a, 0u, 0u, 0u, 1u);
    aurora_set_song_length(a, 0u, 1u);
    aurora_set_track_pattern(a, 0u, 3u);
    aurora_set_step(a, 0u, 3u, 7u, 60u, 111u, 82u, 93u);
    aurora_render(a, audio, AURORA_BLOCK_FRAMES);
    {
        uint8_t preset = 255u, pattern = 255u;
        AuroraStep step;
        char preset_name[AURORA_NAME_LEN];
        assert(aurora_get_track_settings(a, 0u, &preset, &pattern, NULL, NULL));
        assert(pattern == 3u);
        assert(aurora_get_song_length(a, 0u) == 1u);
        assert(aurora_get_song_length(a, AURORA_TRACKS) == 0u);
        assert(aurora_get_step(a, 0u, 3u, 7u, &step));
        assert(step.note == 60u && step.velocity == 111u && step.gate == 82u && step.probability == 93u);
        assert(aurora_get_preset_name(a, preset, preset_name, sizeof(preset_name)));
        assert(preset_name[0] != '\0');
    }
    assert(aurora_core1_enabled(a));
    assert(aurora_core1_faults(a) == 0u);
    assert(aurora_core1_jobs(a) > 0u);
    project_bytes = aurora_project_blob_size();
    project = malloc(project_bytes);
    assert(project != NULL);
    {
        int exported = aurora_project_export_prepare(a, project, project_bytes);
        assert(exported == (int)project_bytes);
        assert(aurora_project_export_seal(project, project_bytes));
    }
    ((unsigned char *)project)[project_bytes - 7u] ^= 0x40u;
    {
        int imported = aurora_project_import(a, project, project_bytes);
        assert(!imported);
    }
    ((unsigned char *)project)[project_bytes - 7u] ^= 0x40u;
    {
        int imported = aurora_project_import(a, project, project_bytes);
        assert(imported);
    }
    free(project);
    aurora_midi_init(&midi);
    aurora_midi_feed(a, &midi, 0x90u, 0u);
    aurora_midi_feed(a, &midi, 67u, 0u);
    aurora_midi_feed(a, &midi, 96u, 0u);
    aurora_render(a, audio, AURORA_BLOCK_FRAMES);
    for (i = 0; i < 12u; ++i) aurora_note_off(a, (uint8_t)(i % AURORA_TRACKS), (uint8_t)(48u + i));
    aurora_stop(a);
    aurora_render(a, audio, AURORA_BLOCK_FRAMES);
    aurora_host_platform_stop(&worker);
    free(mem);

    /* A missing/late CPU1 response must retire the worker and fall back to core 0. */
    {
        AuroraPlatform failing = { fake_submit, fake_wait, fake_retire, NULL };
        void *fallback_mem = calloc(1u, aurora_instance_size());
        Aurora *fallback = aurora_init(fallback_mem, aurora_instance_size(), &failing);
        assert(fallback != NULL);
        for (i = 0; i < 12u; ++i) aurora_note_on(fallback, (uint8_t)(i % AURORA_TRACKS), (uint8_t)(52u + i), 100u);
        aurora_render(fallback, audio, AURORA_BLOCK_FRAMES);
        assert(aurora_core1_faults(fallback) == 1u);
        assert(!aurora_core1_enabled(fallback));
        free(fallback_mem);
    }
    /* FM-1 audio uses 256-frame blocks. Exercise that size on CPU0 alone
       with every voice active; this validates the portable fallback path, not
       the physical AC791N deadline. */
    {
        void *single_mem = calloc(1u, aurora_instance_size());
        Aurora *single;
        float block256[AURORA_BLOCK_FRAMES * 2u];
        assert(single_mem != NULL);
        single = aurora_init(single_mem, aurora_instance_size(), NULL);
        assert(single != NULL);
        assert(!aurora_core1_enabled(single));
        for (i = 0; i < AURORA_VOICES; ++i)
            aurora_note_on(single, (uint8_t)(i % AURORA_TRACKS),
                           (uint8_t)(48u + i), 112u);
        for (i = 0; i < 8u; ++i) {
            uint32_t j;
            aurora_render(single, block256, AURORA_BLOCK_FRAMES);
            for (j = 0; j < AURORA_BLOCK_FRAMES * 2u; ++j)
                assert(isfinite(block256[j]));
        }
        assert(aurora_active_voices(single) == AURORA_VOICES);
        assert(aurora_core1_faults(single) == 0u);
        free(single_mem);
    }
    puts("AURORA core tests passed");
    return 0;
}
